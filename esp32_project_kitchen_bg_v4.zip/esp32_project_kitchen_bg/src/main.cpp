/*
  ============================================================
  Mostafa_Badawy_Controller_V2  -  ESP32 Smart Control Panel
  ============================================================
  - 6 مفاتيح (ريليهات) بتصميم عصري شبه Tuya Smart
  - أي ريليه ممكن تحوّله لـ "تايمر 1 ثانية" من صفحة Edit Names
  - تايمر مواعيد (كشاف يفتح ويقفل في ساعات تحددها انت بنفسك، مبني على وقت الإنترنت NTP)
  - زرار طوارئ فيزيائي + من المتصفح (يشغل أول 4 مفاتيح ويبعت إشعار موبايل)
  - سويتشات (Toggle) بدل الأزرار
  - Bottom Navigation Bar بالأيقونات
  - اسم عام للجهاز (Panel Title) قابل للتعديل
  - تحديث الفيرموير عن بُعد (OTA) عن طريق رفع ملف .bin من المتصفح
  - نسخ احتياطي واسترجاع لكل الإعدادات (Backup / Restore) كملف JSON
  - صفحة WiFi Settings (اتصال + Access Point دايمًا شغالة)
  - صفحة MQTT Settings (Broker / Prefix / Port)
  - حفظ كل الإعدادات في الفلاش (Preferences)
  - تأكيد (Confirm) قبل الريستارت أو مسح الإعدادات
  - دعم MQTT: topics
        prefix/control/relayX   ->  ON / OFF
        prefix/status/relayX    ->  ON / OFF
        prefix/control/all      ->  ON / OFF
        prefix/status/all       ->  ON / OFF

  المكتبات (PlatformIO هيحملها لوحده من platformio.ini):
   - PubSubClient (knolleary)
  ============================================================
*/

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <PubSubClient.h>
#include <Update.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <time.h>
#include "mbedtls/md.h"
#include "bg_image.h"

// ------------------- إعدادات البينات (ESP32 DevKit V1 / esp32dev - 30/38 بين) -------------------
// 6 ريليهات بس، على بينات آمنة تمامًا ومالهاش أي علاقة بمنطق الإقلاع (Strapping Pins) زي GPIO0/2/5/12/15
// وبعيدة كمان عن بينات الفلاش الداخلي (GPIO6-11) وبينات الـ Input-Only (GPIO34-39)
#define RELAY_COUNT 6
const int relayPins[RELAY_COUNT] = {26, 27, 14, 25, 32, 33}; // GPIO26, GPIO27, GPIO14, GPIO25, GPIO32, GPIO33

const unsigned long TIMER_DURATION = 1000; // مدة تشغيل وضع التايمر (ميلي ثانية)

// ------------------- زرار الطوارئ (Emergency Button) -------------------
// وصّل زرار (طرف في الجراوند GND والطرف التاني في البين دا)
// GPIO4 بين عام سليم على ESP32، بيدعم Internal Pull-up ومالهوش أي علاقة بالإقلاع
const int emergencyButtonPin = 4; // GPIO4
const int EMERGENCY_RELAY_COUNT = 4; // أول 4 مفاتيح بس اللي بتشتغل وقت الطوارئ
const unsigned long EMERGENCY_DURATION = 30UL * 60UL * 1000UL; // 30 دقيقة
const unsigned long EMERGENCY_RETRIGGER_COOLDOWN = 5000; // ميلي ثانية - يمنع تكرار التفعيل بضغطة واحدة

bool emergencyActive = false;
unsigned long emergencyStartTime = 0;
bool emergencyButtonHeld = false;
unsigned long emergencyLastTrigger = 0;
bool emergencyButtonEnabled = true; // لو false، الزرار الفيزيائي مش هيشتغل (وضع "أنا موجود في البيت")

// ------------------- إعدادات إشعارات ntfy.sh -------------------
// تطبيق ntfy مجاني وبيبعت إشعار فوري للموبايل من غير تسجيل حساب
// نزّل تطبيق ntfy من المتجر واعمل Subscribe لنفس اسم التوبيك اللي هتكتبه هنا
String ntfyTopic = "";

// أغلب لوحات الريليه الجاهزة بتشتغل بمنطق معكوس (LOW = تشغيل، HIGH = إيقاف)
// لو الريليهات عندك عكس (تفتح لما المفروض تقفل)، سيب القيمة true
// لو عايز ترجعها للوضع العادي (HIGH = تشغيل)، خليها false
const bool RELAY_ACTIVE_LOW = true;

// حالة كل ريليه
bool relayState[RELAY_COUNT] = {false, false, false, false, false, false};
bool relayIsTimer[RELAY_COUNT] = {false, false, false, false, false, false};
bool timerActive[RELAY_COUNT] = {false, false, false, false, false, false};
unsigned long relayTimerStart[RELAY_COUNT] = {0, 0, 0, 0, 0, 0};

// أسماء افتراضية للريليهات
String relayNames[RELAY_COUNT] = {
  "لمبة 1", "لمبة 2", "لمبة 3", "لمبة 4", "ليد زينة", "شريط ليد"
};

String panelTitle = "Mostafa Badawy Controller";
String peerBoardUrl = ""; // آي بي أو اسم البورد التاني على نفس الشبكة (للتنقل بينهم من أيقونة 🔀)

// ------------------- درجة تعديم (Dimming) عامة - شكل بصري بس في صفحة التحكم -------------------
// ملحوظة: ده مؤثر بصري في صفحة الويب بس (بيوهّج/يخفّت شكل أيقونات ولمبات المفاتيح على الشاشة)
// ومالوش أي علاقة بالتحكم الفعلي في الريليهات نفسها - المفاتيح شغالة تشغيل/إيقاف عادي زي ما هي.
int globalBrightness = 100; // 0-100%

// ------------------- تايمر مواعيد (كل ريليه/كشاف له جدول خاص بيه، يفتح ويقفل في ساعات تحددها انت) -------------------
bool schedEnabled[RELAY_COUNT]   = {false, false, false, false, false, false};
int  schedOnHour[RELAY_COUNT]    = {18, 18, 18, 18, 18, 18};   // الساعة اللي هيفتح فيها كل ريليه (نظام 24 ساعة)
int  schedOnMinute[RELAY_COUNT]  = {0, 0, 0, 0, 0, 0};
int  schedOffHour[RELAY_COUNT]   = {6, 6, 6, 6, 6, 6};         // الساعة اللي هيقفل فيها كل ريليه
int  schedOffMinute[RELAY_COUNT] = {0, 0, 0, 0, 0, 0};
int  schedGmtOffset = 2;   // فرق التوقيت عن جرينتش بالساعات (مصر = 2) - إعداد عام واحد لكل الأجهزة

// ------------------- إعدادات الشبكة -------------------
String staSsid = "";
String staPass = "";

// حجز IP ثابت للبورد نفسه (بدل ما ياخد IP عشوائي كل مرة من الروتر)
// لازم تكتب بيانات صح ومتوافقة مع شبكتك (الجيت واي والسبنت ماسك بتوع الروتر عندك)
bool staUseStaticIp = false;
String staStaticIp = "";       // مثال: 192.168.1.200
String staStaticGateway = "";  // مثال: 192.168.1.1 (عادة هو نفسه IP بتاع الروتر)
String staStaticSubnet = "255.255.255.0";
String staStaticDns = "";      // اختياري، لو فاضي هيستخدم نفس الجيت واي

String apSsid = "Mostafa Home";
String apPass = "MOstafa@2000";
bool apHidden = false;

// ------------------- إعدادات MQTT -------------------
String mqttBroker = "broker.hivemq.com";
String mqttPrefix = "mostafabadawy";
int mqttPort = 1883;
bool mqttEnabled = true;

// مفتاح الربط (Pairing Key) - نفس المفتاح لازم يكون متحط في إعدادات التطبيق.
// بيُستخدم لحساب توقيع HMAC-SHA256 لرسالة الاكتشاف (discovery) عشان التطبيق
// يتأكد إن الرسالة جاية من الفيرموير بتاعك انت بس، مش من أي بورد تاني.
String pairingKey = "";

WebServer server(80);
Preferences prefs;

String restoreBuffer = "";
bool otaUploadOk = false;
String otaErrorMsg = "";

WiFiClient espClient;
PubSubClient mqttClient(espClient);

// ============================================================
//                       تخزين الإعدادات
// ============================================================
void loadSettings() {
  prefs.begin("mostafabdw", true);

  staSsid = prefs.getString("sta_ssid", "");
  staPass = prefs.getString("sta_pass", "");

  staUseStaticIp  = prefs.getBool("sip_en", false);
  staStaticIp      = prefs.getString("sip_ip", "");
  staStaticGateway = prefs.getString("sip_gw", "");
  staStaticSubnet  = prefs.getString("sip_sub", "255.255.255.0");
  staStaticDns     = prefs.getString("sip_dns", "");

  apSsid   = prefs.getString("ap_ssid", apSsid);
  apPass   = prefs.getString("ap_pass", apPass);
  apHidden = prefs.getBool("ap_hidden", false);

  mqttBroker = prefs.getString("mqtt_broker", mqttBroker);
  mqttPrefix = prefs.getString("mqtt_prefix", mqttPrefix);
  mqttPort   = prefs.getInt("mqtt_port", mqttPort);
  pairingKey = prefs.getString("pairing_key", pairingKey);

  panelTitle = prefs.getString("panel_title", panelTitle);

  ntfyTopic = prefs.getString("ntfy_topic", ntfyTopic);
  emergencyButtonEnabled = prefs.getBool("em_btn_en", true);

  schedGmtOffset = prefs.getInt("sch_gmt", 2);
  peerBoardUrl   = prefs.getString("peer_ip", "");
  globalBrightness = prefs.getInt("brightness", 100);

  for (int i = 0; i < RELAY_COUNT; i++) {
    String nameKey  = "rn_" + String(i);
    String timerKey = "rt_" + String(i);
    relayNames[i]   = prefs.getString(nameKey.c_str(), relayNames[i]);
    relayIsTimer[i] = prefs.getBool(timerKey.c_str(), false);

    schedEnabled[i]   = prefs.getBool(("sch_en" + String(i)).c_str(), false);
    schedOnHour[i]    = prefs.getInt(("sch_onh" + String(i)).c_str(), 18);
    schedOnMinute[i]  = prefs.getInt(("sch_onm" + String(i)).c_str(), 0);
    schedOffHour[i]   = prefs.getInt(("sch_offh" + String(i)).c_str(), 6);
    schedOffMinute[i] = prefs.getInt(("sch_offm" + String(i)).c_str(), 0);
  }

  prefs.end();
}

void saveWifiSettings(String ssid, String pass) {
  prefs.begin("mostafabdw", false);
  prefs.putString("sta_ssid", ssid);
  prefs.putString("sta_pass", pass);
  prefs.end();
}

void saveStaticIpSettings(bool en, String ip, String gw, String sub, String dns) {
  prefs.begin("mostafabdw", false);
  prefs.putBool("sip_en", en);
  prefs.putString("sip_ip", ip);
  prefs.putString("sip_gw", gw);
  prefs.putString("sip_sub", sub);
  prefs.putString("sip_dns", dns);
  prefs.end();
}

void saveApSettings(String ssid, String pass, bool hidden) {
  prefs.begin("mostafabdw", false);
  prefs.putString("ap_ssid", ssid);
  prefs.putString("ap_pass", pass);
  prefs.putBool("ap_hidden", hidden);
  prefs.end();
}

void saveMqttSettings(String broker, String prefix, int port) {
  prefs.begin("mostafabdw", false);
  prefs.putString("mqtt_broker", broker);
  prefs.putString("mqtt_prefix", prefix);
  prefs.putInt("mqtt_port", port);
  prefs.end();
}

void savePairingKey(String key) {
  prefs.begin("mostafabdw", false);
  prefs.putString("pairing_key", key);
  prefs.end();
}

void saveRelayNamesAndTimers() {
  prefs.begin("mostafabdw", false);
  for (int i = 0; i < RELAY_COUNT; i++) {
    String nameKey  = "rn_" + String(i);
    String timerKey = "rt_" + String(i);
    prefs.putString(nameKey.c_str(), relayNames[i]);
    prefs.putBool(timerKey.c_str(), relayIsTimer[i]);
  }
  prefs.end();
}

void savePanelTitle(String title) {
  prefs.begin("mostafabdw", false);
  prefs.putString("panel_title", title);
  prefs.end();
}

void saveNtfyTopic(String topic) {
  prefs.begin("mostafabdw", false);
  prefs.putString("ntfy_topic", topic);
  prefs.end();
}

void saveEmergencyButtonEnabled(bool en) {
  prefs.begin("mostafabdw", false);
  prefs.putBool("em_btn_en", en);
  prefs.end();
}

void saveScheduleForRelay(int relay, bool en, int onH, int onM, int offH, int offM) {
  prefs.begin("mostafabdw", false);
  prefs.putBool(("sch_en" + String(relay)).c_str(), en);
  prefs.putInt(("sch_onh" + String(relay)).c_str(), onH);
  prefs.putInt(("sch_onm" + String(relay)).c_str(), onM);
  prefs.putInt(("sch_offh" + String(relay)).c_str(), offH);
  prefs.putInt(("sch_offm" + String(relay)).c_str(), offM);
  prefs.end();
}

void saveScheduleGmt(int gmt) {
  prefs.begin("mostafabdw", false);
  prefs.putInt("sch_gmt", gmt);
  prefs.end();
}

void savePeerBoard(String url) {
  prefs.begin("mostafabdw", false);
  prefs.putString("peer_ip", url);
  prefs.end();
}

void saveBrightness(int val) {
  prefs.begin("mostafabdw", false);
  prefs.putInt("brightness", val);
  prefs.end();
}

void clearAllSettings() {
  prefs.begin("mostafabdw", false);
  prefs.clear();
  prefs.end();
}

// ============================================================
//                       MQTT (Forward declarations)
// ============================================================
void publishStatus(int index);
void publishAllStatus();
void publishDiscovery();

// ============================================================
//                       التحكم في الريليهات
// ============================================================
// بيطبّق حالة التشغيل الفعلية على بين مفتاح معيّن (ON/OFF عادي)
void applyRelayOutput(int index) {
  if (index < 0 || index >= RELAY_COUNT) return;
  bool state = relayState[index];
  digitalWrite(relayPins[index], RELAY_ACTIVE_LOW ? (state ? LOW : HIGH) : (state ? HIGH : LOW));
}

void setRelay(int index, bool state) {
  if (index < 0 || index >= RELAY_COUNT) return;
  relayState[index] = state;
  applyRelayOutput(index);

  if (relayIsTimer[index]) {
    if (state) {
      timerActive[index] = true;
      relayTimerStart[index] = millis();
    } else {
      timerActive[index] = false;
    }
  }

  publishStatus(index);
}

void setAllRelays(bool state) {
  for (int i = 0; i < RELAY_COUNT; i++) {
    setRelay(i, state);
  }
  publishAllStatus();
}

void checkTimers() {
  unsigned long now = millis();
  for (int i = 0; i < RELAY_COUNT; i++) {
    if (timerActive[i] && now - relayTimerStart[i] >= TIMER_DURATION) {
      timerActive[i] = false;
      setRelay(i, false);
    }
  }
}

// ============================================================
//                 تايمر المواعيد (كشاف يشتغل ويقفل في ساعات محددة)
// ============================================================
bool anyScheduleEnabled() {
  for (int i = 0; i < RELAY_COUNT; i++) {
    if (schedEnabled[i]) return true;
  }
  return false;
}

void checkSchedule() {
  if (!anyScheduleEnabled()) return;

  static unsigned long lastCheck = 0;
  unsigned long now = millis();
  if (now - lastCheck < 15000) return; // فحص كل 15 ثانية يكفي
  lastCheck = now;

  time_t t = time(nullptr);
  if (t < 1700000000) return; // الوقت لسه مايتزامنش من الإنترنت (NTP)

  t += (long)schedGmtOffset * 3600L; // تطبيق فرق التوقيت المحلي يدويًا
  struct tm *tmNow = gmtime(&t);
  int curMinutes = tmNow->tm_hour * 60 + tmNow->tm_min;

  for (int i = 0; i < RELAY_COUNT; i++) {
    if (!schedEnabled[i]) continue;

    int onMinutes  = schedOnHour[i] * 60 + schedOnMinute[i];
    int offMinutes = schedOffHour[i] * 60 + schedOffMinute[i];

    bool shouldBeOn;
    if (onMinutes == offMinutes) {
      shouldBeOn = false; // إعداد متطابق، اعتبره مقفول
    } else if (onMinutes < offMinutes) {
      shouldBeOn = (curMinutes >= onMinutes && curMinutes < offMinutes);
    } else {
      shouldBeOn = (curMinutes >= onMinutes || curMinutes < offMinutes); // الجدول بيعدي نص الليل
    }

    if (shouldBeOn != relayState[i]) {
      setRelay(i, shouldBeOn);
      Serial.println(shouldBeOn ? ("⏰ الجدول: تشغيل " + relayNames[i]) : ("⏰ الجدول: إيقاف " + relayNames[i]));
    }
  }
}

// ============================================================
//                       إشعار ntfy.sh
// ============================================================
void sendNtfyNotification(String title, String message) {
  if (ntfyTopic.length() == 0) {
    Serial.println("⚠️ ntfy: مفيش اسم توبيك محفوظ، الإشعار اتلغى.");
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("⚠️ ntfy: مفيش اتصال بالإنترنت (الراوتر)، الإشعار اتلغى.");
    return;
  }

  WiFiClientSecure client;
  client.setInsecure(); // نتخطى التحقق من الشهادة عشان نبسّط الاتصال
  HTTPClient https;
  https.setTimeout(8000);

  String url = "https://ntfy.sh/" + ntfyTopic;
  Serial.println("🔔 بعتنا إشعار لـ: " + url + " | رام فاضي: " + String(ESP.getFreeHeap()));
  if (https.begin(client, url)) {
    https.addHeader("Title", title);
    https.addHeader("Priority", "urgent");
    https.addHeader("Tags", "rotating_light");
    int code = https.POST(message);
    if (code > 0) {
      Serial.printf("✅ ntfy notification result: %d\n", code);
    } else {
      Serial.printf("❌ ntfy فشل الإرسال، كود الخطأ: %d (%s)\n", code, https.errorToString(code).c_str());
    }
    https.end();
  } else {
    Serial.println("❌ فشل فتح الاتصال بـ ntfy.sh (مشكلة رام أو شبكة)");
  }
}

// ============================================================
//                       زرار الطوارئ (Emergency Button)
// ============================================================
void activateEmergency() {
  if (emergencyActive) return; // شغال بالفعل، متجاهلش الضغطة
  emergencyActive = true;
  emergencyStartTime = millis();

  for (int i = 0; i < EMERGENCY_RELAY_COUNT; i++) {
    relayState[i] = true;
    applyRelayOutput(i);
    timerActive[i] = false; // وقت الطوارئ الريليه فاضل شغال 30 دقيقة، مش تايمر 1 ثانية
    publishStatus(i);
  }

  if (mqttClient.connected()) {
    mqttClient.publish((mqttPrefix + "/status/emergency").c_str(), "ON", true);
  }

  Serial.println("🚨 تم تفعيل زرار الطوارئ!");
  sendNtfyNotification(
    "🚨 طوارئ - " + panelTitle,
    "تم الضغط على زرار الطوارئ! أول 4 مفاتيح اشتغلت وهتفضل شغالة لمدة 30 دقيقة."
  );
}

void deactivateEmergency(bool notify = false) {
  if (!emergencyActive) return;
  emergencyActive = false;

  for (int i = 0; i < EMERGENCY_RELAY_COUNT; i++) {
    relayState[i] = false;
    applyRelayOutput(i);
    publishStatus(i);
  }

  if (mqttClient.connected()) {
    mqttClient.publish((mqttPrefix + "/status/emergency").c_str(), "OFF", true);
  }

  Serial.println("تم إيقاف وضع الطوارئ");
  if (notify) {
    sendNtfyNotification("✅ " + panelTitle, "تم إيقاف وضع الطوارئ يدويًا.");
  }
}

void checkEmergencyButton() {
  bool pressed = (digitalRead(emergencyButtonPin) == LOW);

  if (pressed && !emergencyButtonHeld) {
    delay(30); // ديباونس بسيط
    if (digitalRead(emergencyButtonPin) == LOW) {
      emergencyButtonHeld = true;
      if (emergencyButtonEnabled && millis() - emergencyLastTrigger > EMERGENCY_RETRIGGER_COOLDOWN) {
        emergencyLastTrigger = millis();
        activateEmergency();
      }
    }
  } else if (!pressed) {
    emergencyButtonHeld = false;
  }
}

void checkEmergencyTimer() {
  if (emergencyActive && millis() - emergencyStartTime >= EMERGENCY_DURATION) {
    deactivateEmergency(false);
  }
}

// ============================================================
//                       MQTT
// ============================================================
String topicControl(int index) { return mqttPrefix + "/control/relay" + String(index + 1); }
String topicStatus(int index)  { return mqttPrefix + "/status/relay" + String(index + 1); }
String topicControlAll() { return mqttPrefix + "/control/all"; }
String topicStatusAll()  { return mqttPrefix + "/status/all"; }
String topicControlEmergency() { return mqttPrefix + "/control/emergency"; }
String topicControlEmergencyButton() { return mqttPrefix + "/control/emergencybutton"; }
String topicStatusEmergencyButton()  { return mqttPrefix + "/status/emergencybutton"; }

// توبيك "توفر" البورد (Availability) - رسالة Retained + Last Will، عشان
// التطبيق يعرف لما البورد يتصل أو يتقطع فجأة. لازم يتسجل كـ LWT وقت
// mqttClient.connect() في mqttReconnect().
String topicAvailability() { return mqttPrefix + "/availability"; }
String topicDiscovery()    { return mqttPrefix + "/discovery"; }

// ============================================================
//         Discovery (اكتشاف البورد) - نفس بروتوكول التطبيق بالظبط
// ============================================================
// بيبني نفس الـ "canonical string" اللي التطبيق بيبنيه في discovery.js
// (buildCanonicalString) بنفس الترتيب بالظبط، وبيوقّعه بـ HMAC-SHA256
// باستخدام "مفتاح الربط". أي اختلاف بسيط في الترتيب أو الفواصل هيخلي
// التوقيع مايتطابقش والتطبيق هيرفض البورد.
String hmacSha256Hex(const String& key, const String& message) {
  byte hmacResult[32];
  mbedtls_md_context_t ctx;
  mbedtls_md_type_t mdType = MBEDTLS_MD_SHA256;

  mbedtls_md_init(&ctx);
  mbedtls_md_setup(&ctx, mbedtls_md_info_from_type(mdType), 1 /* HMAC */);
  mbedtls_md_hmac_starts(&ctx, (const unsigned char*)key.c_str(), key.length());
  mbedtls_md_hmac_update(&ctx, (const unsigned char*)message.c_str(), message.length());
  mbedtls_md_hmac_finish(&ctx, hmacResult);
  mbedtls_md_free(&ctx);

  String hex = "";
  char buf[3];
  for (int i = 0; i < 32; i++) {
    sprintf(buf, "%02x", hmacResult[i]);
    hex += buf;
  }
  return hex;
}

// بيبني جزء المفاتيح (swPart) بنفس ترتيب discovery.js بالظبط:
// name,control_topic,status_topic,icon,control_type  --- مفصولة بـ ; بين كل مفتاح
String buildSwitchesCanonicalPart() {
  String swPart = "";
  for (int i = 0; i < RELAY_COUNT; i++) {
    if (i > 0) swPart += ";";
    swPart += relayNames[i] + "," + topicControl(i) + "," + topicStatus(i) + ",lamp,toggle";
  }
  return swPart;
}

void publishDiscovery() {
  if (!mqttClient.connected()) return;
  if (pairingKey.length() == 0) return; // لازم مفتاح ربط قبل ما نبعت اكتشاف

  String deviceId = mqttPrefix;
  String name = panelTitle;
  String type = "switches";
  String prefixField = ""; // فاضية لبورد switches (زي ما discovery.js متوقع)
  String swPart = buildSwitchesCanonicalPart();

  // نفس ترتيب buildCanonicalString في discovery.js:
  // [device_id, name, type, prefix, swPart].join('|')
  String canonical = deviceId + "|" + name + "|" + type + "|" + prefixField + "|" + swPart;
  String sig = hmacSha256Hex(pairingKey, canonical);

  DynamicJsonDocument doc(2048);
  doc["device_id"] = deviceId;
  doc["name"] = name;
  doc["type"] = type;
  JsonArray switches = doc.createNestedArray("switches");
  for (int i = 0; i < RELAY_COUNT; i++) {
    JsonObject sw = switches.createNestedObject();
    sw["name"] = relayNames[i];
    sw["control_topic"] = topicControl(i);
    sw["status_topic"] = topicStatus(i);
    sw["icon"] = "lamp";
    sw["control_type"] = "toggle";
  }
  doc["sig"] = sig;

  String payload;
  serializeJson(doc, payload);

  bool ok = mqttClient.publish(topicDiscovery().c_str(), payload.c_str(), true /* retained */);
  if (!ok) {
    Serial.println("⚠️ فشل نشر رسالة discovery — الرسالة أكبر من buffer الـ MQTT الحالي");
  }
}

void publishStatus(int index) {
  if (!mqttClient.connected()) return;
  mqttClient.publish(topicStatus(index).c_str(), relayState[index] ? "ON" : "OFF", true);
}

void publishAllStatus() {
  if (!mqttClient.connected()) return;
  for (int i = 0; i < RELAY_COUNT; i++) publishStatus(i);
}

void publishEmergencyButtonStatus() {
  if (!mqttClient.connected()) return;
  mqttClient.publish(topicStatusEmergencyButton().c_str(), emergencyButtonEnabled ? "ON" : "OFF", true);
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];
  msg.trim();
  bool state = msg.equalsIgnoreCase("ON");

  String t = String(topic);

  if (t == topicControlAll()) {
    setAllRelays(state);
    return;
  }

  if (t == topicControlEmergency()) {
    if (state) activateEmergency();
    else deactivateEmergency(true);
    return;
  }

  if (t == topicControlEmergencyButton()) {
    emergencyButtonEnabled = state;
    saveEmergencyButtonEnabled(state);
    publishEmergencyButtonStatus();
    return;
  }

  for (int i = 0; i < RELAY_COUNT; i++) {
    if (t == topicControl(i)) {
      setRelay(i, state);
      return;
    }
  }
}

void mqttReconnect() {
  if (!mqttEnabled) return;
  if (mqttClient.connected()) return;
  if (WiFi.status() != WL_CONNECTED) return;

  String clientId = "MostafaBadawyESP32-" + String((uint32_t)(ESP.getEfuseMac() >> 16), HEX);

  // بنسجل توبيك الـ availability كـ Last Will (LWT) هنا: لو البورد اتقطع
  // فجأة (نت/كهرباء) من غير ما يقدر يبعت رسالة وداع بنفسه، البروكر هو اللي
  // هينشر "offline" تلقائي على التطبيق.
  bool connected = mqttClient.connect(
    clientId.c_str(),
    topicAvailability().c_str(),      // willTopic
    0,                                 // willQos
    true,                              // willRetain
    "offline"                          // willMessage
  );

  if (connected) {
    mqttClient.subscribe(topicControlAll().c_str());
    mqttClient.subscribe(topicControlEmergency().c_str());
    mqttClient.subscribe(topicControlEmergencyButton().c_str());
    for (int i = 0; i < RELAY_COUNT; i++) {
      mqttClient.subscribe(topicControl(i).c_str());
    }
    mqttClient.publish(topicAvailability().c_str(), "online", true /* retained */);
    publishDiscovery();
    publishAllStatus();
    publishEmergencyButtonStatus();
  }
}

// ============================================================
//                       WiFi
// ============================================================
void startAccessPoint() {
  WiFi.softAP(apSsid.c_str(), apPass.c_str(), 1, apHidden ? 1 : 0);
  Serial.print("Access Point: ");
  Serial.println(apSsid);
  Serial.print("AP IP: ");
  Serial.println(WiFi.softAPIP());
}

// يحاول يظبط IP ثابت على الواي فاي (STA). لو أي قيمة غلط أو فاضية، بيرجع false
// وساعتها البورد هياخد IP عادي (تلقائي) من الروتر عادي من غير ما يبوظ حاجة
bool applyStaticIpIfNeeded() {
  if (!staUseStaticIp) return false;

  IPAddress ip, gw, sub, dns;
  if (!ip.fromString(staStaticIp)) return false;
  if (!gw.fromString(staStaticGateway)) return false;
  if (!sub.fromString(staStaticSubnet)) sub = IPAddress(255, 255, 255, 0);

  if (staStaticDns.length() > 0) {
    if (!dns.fromString(staStaticDns)) dns = gw;
  } else {
    dns = gw;
  }

  bool ok = WiFi.config(ip, gw, sub, dns);
  if (ok) {
    Serial.print("تم ضبط IP ثابت: ");
    Serial.println(ip);
  } else {
    Serial.println("فشل ضبط الـ IP الثابت، هيتم الاعتماد على DHCP");
  }
  return ok;
}

void connectToWifi() {
  if (staSsid.length() == 0) return;

  applyStaticIpIfNeeded(); // لازم قبل WiFi.begin

  WiFi.begin(staSsid.c_str(), staPass.c_str());
  Serial.print("جاري الاتصال بـ: ");
  Serial.println(staSsid);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
    delay(300);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("متصل! IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("فشل الاتصال بالشبكة، هيتم الاعتماد على الـ Access Point فقط");
  }
}

// لو الاتصال بالراوتر اتقطع بعد التشغيل (الراوتر اتقفل ورجع، ضعف إشارة، إلخ)
// الكود الأصلي مكانش بيحاول يتصل تاني تلقائيًا، فالبورد كان فاضل واقف على AP بس
// للأبد لحد ما حد يعمل له Restart يدوي. الدالة دي بتتأكد كل شوية وتعيد المحاولة.
void checkWifiConnection() {
  static unsigned long lastAttempt = 0;
  if (staSsid.length() == 0) return; // مفيش شبكة محفوظة أصلاً

  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - lastAttempt > 15000) { // كل 15 ثانية
      lastAttempt = millis();
      Serial.println("⚠️ مفيش اتصال بالراوتر، جاري إعادة المحاولة...");
      WiFi.disconnect();
      applyStaticIpIfNeeded();
      WiFi.begin(staSsid.c_str(), staPass.c_str());
    }
    return;
  }

  // متصل بس الإشارة ضعيفة جدًا (ممكن تسبب بطء أو تقطيع في تحميل الصفحة) - نجرب نعيد الاتصال عله يمسك إشارة أحسن
  static unsigned long weakSince = 0;
  static unsigned long lastWeakReconnect = 0;
  const int RSSI_WEAK_THRESHOLD = -82; // dBm - تحت الرقم ده الاتصال بيبقى غير مستقر
  int rssi = WiFi.RSSI();

  if (rssi < RSSI_WEAK_THRESHOLD) {
    if (weakSince == 0) weakSince = millis();
    // لو الإشارة فضلت ضعيفة لمدة دقيقة كاملة، وماحاولناش نعيد الاتصال من 60 ثانية على الأقل
    if (millis() - weakSince > 60000 && millis() - lastWeakReconnect > 60000) {
      lastWeakReconnect = millis();
      Serial.println("⚠️ إشارة WiFi ضعيفة جدًا (" + String(rssi) + " dBm)، جاري محاولة إعادة اتصال لالتقاط إشارة أحسن...");
      WiFi.disconnect();
      applyStaticIpIfNeeded();
      WiFi.begin(staSsid.c_str(), staPass.c_str());
    }
  } else {
    weakSince = 0; // الإشارة رجعت كويسة، صفّر العداد
  }
}

// ============================================================
//                   HTML Header - Modern Design (Light build)
// ============================================================
// بيدور على أول (أو تاني، حسب skip) ريليه اسمه فيه الكلمة المطلوبة - عشان نربط كل سبوت في الصورة بالمفتاح المطابق بالاسم مهما كان ترتيبهم
int findRelayByName(String sub, int skip = 0) {
  int found = 0;
  for (int i = 0; i < RELAY_COUNT; i++) {
    if (relayNames[i].indexOf(sub) >= 0) {
      if (found == skip) return i;
      found++;
    }
  }
  return -1;
}

// نقط التوهج فوق السبوتات الحقيقية في صورة الخلفية - كل نقطة بتضيء لما المفتاح المرتبط بيها يشتغل
String lightspotsHtml() {
  const float IMG_ASPECT = 2.16714; // نسبة طول/عرض صورة الخلفية (700x1517) - تحويل % الارتفاع لوحدة vw عشان تتزامن مع عرض الصورة مهما كان حجم الشاشة
  struct Spot { const char* nameSub; int skip; float xPct; float yPct; bool strip; float wPct; };
  Spot spots[8] = {
    {"شمال", 0, 29.0, 11.5, false, 0},
    {"يمين", 0, 71.0, 11.5, false, 0},
    {"التصف", 0, 40.0, 11.5, false, 0},
    {"التصف", 1, 60.0, 11.5, false, 0},
    // بار -> فوانيس الزينة المتعلقة (3 نقط على امتداد الخيط المترهل)
    {"بار", 0, 30.0, 13.8, false, 0},
    {"بار", 0, 43.0, 16.2, false, 0},
    {"بار", 0, 56.0, 13.9, false, 0},
    // خلف -> الشريط الأصفر (كوف لايت) فوق السقف
    {"خلف", 0, 50.0, 5.5, true, 78.0},
  };
  String html = "<div class='lightlayer'>";
  for (int s = 0; s < 8; s++) {
    int idx = findRelayByName(String(spots[s].nameSub), spots[s].skip);
    bool on = (idx >= 0) ? relayState[idx] : false;
    float topVw = spots[s].yPct * IMG_ASPECT;
    if (spots[s].strip) {
      html += "<div class='lightstrip" + String(on ? " on" : "") + "' style='left:" + String(spots[s].xPct - spots[s].wPct / 2.0, 1) + "%;top:" + String(topVw, 1) + "vw;width:" + String(spots[s].wPct, 1) + "%;'></div>";
    } else {
      html += "<div class='lightspot" + String(on ? " on" : "") + "' style='left:" + String(spots[s].xPct, 1) + "%;top:" + String(topVw, 1) + "vw;'></div>";
    }
  }
  html += "</div>";
  return html;
}

String relayIcon(String name) {
  String n = name;
  n.toLowerCase();
  if (n.indexOf("مروح") >= 0 || n.indexOf("fan") >= 0) return "🌀";
  if (n.indexOf("سخان") >= 0 || n.indexOf("heat") >= 0) return "🔥";
  if (n.indexOf("مضخ") >= 0 || n.indexOf("موتور") >= 0 || n.indexOf("pump") >= 0 || n.indexOf("motor") >= 0) return "⚙️";
  if (n.indexOf("حديق") >= 0 || n.indexOf("garden") >= 0) return "🌿";
  if (n.indexOf("مقيس") >= 0 || n.indexOf("بريز") >= 0 || n.indexOf("plug") >= 0 || n.indexOf("socket") >= 0) return "🔌";
  return "💡";
}

// شارة الأيقونة الصغيرة أعلى شمال الكارت - رقم للسبوت المفرد، أو أيقونة حسب موقع/اسم الكشاف
String cardTopLeftBadge(int i, String name) {
  if (name.indexOf("شمال") >= 0) return "📍";
  if (name.indexOf("خلف") >= 0) return "▭";
  if (name.indexOf("بار") >= 0) return "✨";
  if (name.indexOf("يمين") >= 0) return "☀️";
  return String(i + 1); // كشافات مفردة عادية (أسبوت 1، أسبوت 2...)
}

// شارة الأيقونة الصغيرة أعلى يمين الكارت
String cardTopRightBadge(String name) {
  if (name.indexOf("شمال") >= 0 || name.indexOf("يمين") >= 0) return "🛋️";
  return relayIcon(name) == "💡" ? "☀️" : relayIcon(name);
}

// أيقونة لمبة واحدة (تضيء لما المفتاح يكون شغال، وتبقى خطوط رمادية لما يكون واقف)
String bulbIcon(bool st) {
  String cls = String("bulb-ic") + (st ? " on" : "");
  return "<div class='" + cls + "'><svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'><path d='M9 18h6'></path><path d='M10 22h4'></path><path d='M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2.05V17h6v-.25c0-.85.4-1.55 1-2.05A7 7 0 0 0 12 2z'></path></svg></div>";
}

// الرسمة الرئيسية جوه الكارت (لمبة/لمبتين/فوانيس/شريط ليد حسب رقم المفتاح) - وبتضيء حسب حالة التشغيل
String cardMainVisual(int i, String name, bool st) {
  if (i == 4 || name.indexOf("زينة") >= 0) return "<div class='fairy-ic'><span></span><span></span><span></span></div>"; // مفتاح 5: ليد زينة
  if (i == 5 || name.indexOf("شريط") >= 0) return "<div class='strip-ic'></div>"; // مفتاح 6: شريط ليد
  if (i == 2 || i == 3) return "<div class='dualbulb-ic'>" + bulbIcon(st) + bulbIcon(st) + "</div>"; // مفتاح 3 و4: لمبتين
  return bulbIcon(st); // مفتاح 1 و2: لمبة مفردة
}

String htmlHeader(String title) {
  String html = "<!DOCTYPE html><html lang='ar' dir='rtl'><head>";
  html += "<meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<title>" + title + "</title>";
  html += "<style>";

  // ========== Reset & Base Styles ==========
  html += "*{box-sizing:border-box;margin:0;padding:0;}";
  // خلفية بار المطبخ الحقيقية (اتخزنت جوه الفلاش وبتترسل من /bg.jpg) - طبقة تعتيم فوقها عشان الكلام يفضل واضح
  html += "body{background-image:linear-gradient(180deg,rgba(10,8,12,0) 0%,rgba(10,8,12,0) 45%,rgba(10,8,12,.5) 72%,rgba(8,6,10,.85) 90%,rgba(6,5,8,.95) 100%),url('/bg.jpg');background-size:100% auto;background-position:center top;background-repeat:no-repeat;background-attachment:fixed;background-color:#0a0810;color:#f2ead9;font-family:'Segoe UI','Roboto','-apple-system',sans-serif;min-height:100vh;padding-bottom:120px;}";

  // ========== Hero / Topbar (زي الصورة المرجعية: همبرجر - أيقونة بيت/واي فاي - ترس) ==========
  html += ".hero{background:transparent;padding:18px 18px 30px;position:relative;}";
  html += ".topbar{display:flex;align-items:center;justify-content:space-between;}";
  html += ".iconbtn{width:44px;height:44px;border-radius:16px;background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.20);display:flex;align-items:center;justify-content:center;font-size:19px;color:#fff;text-decoration:none;cursor:pointer;flex-shrink:0;}";
  html += ".house-wifi{width:38px;height:38px;color:#f0c479;flex-shrink:0;}";
  html += ".hero h1{text-align:center;font-size:23px;margin:14px 0 0;font-weight:800;color:#fff;}";
  html += ".online-pill{display:flex;width:fit-content;align-items:center;gap:7px;background:rgba(255,255,255,.08);border:1px solid rgba(74,222,128,.55);padding:6px 16px;border-radius:20px;font-size:11px;font-weight:700;letter-spacing:1.5px;color:#7CF0A6;margin:10px auto 0;}";
  html += ".online-pill .dot{width:8px;height:8px;border-radius:50%;background:#4ade80;box-shadow:0 0 8px 2px rgba(74,222,128,.8);}";

  // ========== Side Drawer (بيفتح من زرار الهمبرجر) ==========
  html += ".drawer-overlay{position:fixed;inset:0;background:rgba(0,0,0,.55);opacity:0;pointer-events:none;transition:opacity .25s;z-index:30;}";
  html += ".drawer-overlay.open{opacity:1;pointer-events:auto;}";
  html += ".drawer{position:fixed;top:0;left:0;height:100%;width:76%;max-width:300px;background:#161109;border-right:1.5px solid rgba(217,164,90,.3);transform:translateX(-105%);transition:transform .3s ease;z-index:31;padding:26px 18px;overflow-y:auto;}";
  html += ".drawer.open{transform:translateX(0);}";
  html += ".drawer h3{color:#e3b872;font-size:16px;margin-bottom:16px;font-weight:800;}";
  html += ".drawer a{display:flex;align-items:center;gap:12px;color:#f2ead9;text-decoration:none;padding:13px 10px;border-radius:12px;font-size:14.5px;font-weight:600;margin-bottom:4px;}";
  html += ".drawer a span.dic{width:30px;text-align:center;font-size:17px;}";
  html += ".drawer a:active{background:rgba(217,164,90,.15);}";
  html += ".drawer-close{position:absolute;top:18px;left:18px;background:none;border:none;color:#a99a82;font-size:20px;cursor:pointer;}";

  // ========== Real Light Glow Markers (over the actual spotlights in the photo) ==========
  html += ".lightlayer{pointer-events:none;}";
  html += ".lightspot{position:fixed;width:22px;height:22px;margin-left:-11px;margin-top:-11px;border-radius:50%;background:radial-gradient(circle,rgba(255,220,140,.95),rgba(255,180,90,0) 70%);opacity:0;transition:opacity .5s;pointer-events:none;z-index:1;}";
  html += ".lightspot.on{opacity:1;filter:brightness(var(--b,1));box-shadow:0 0 22px 10px rgba(255,195,120,.55),0 0 48px 20px rgba(255,175,95,.25);animation:lightpulse 2.4s ease-in-out infinite;}";
  html += ".lightstrip{position:fixed;height:12px;margin-top:-6px;border-radius:6px;background:linear-gradient(90deg,rgba(255,205,110,0),rgba(255,200,110,.9) 20%,rgba(255,200,110,.9) 80%,rgba(255,205,110,0));opacity:0;transition:opacity .5s;pointer-events:none;z-index:1;}";
  html += ".lightstrip.on{opacity:1;filter:brightness(var(--b,1));box-shadow:0 0 22px 8px rgba(255,195,120,.4);animation:lightpulse 2.4s ease-in-out infinite;}";
  html += "@keyframes lightpulse{0%,100%{opacity:.82}50%{opacity:1}}";

  // ========== Container & Layout ==========
  html += ".container{max-width:540px;margin:220px auto 0;padding:18px;position:relative;z-index:2;}";
  html += ".quickrow{display:flex;gap:12px;margin-bottom:16px;}";

  // ========== Pills (All ON/OFF) ==========
  html += ".pill{flex:1;display:flex;align-items:center;justify-content:center;gap:10px;padding:14px 12px;border-radius:18px;font-weight:700;text-decoration:none;font-size:15px;color:#fff;border:none;}";
  html += ".pill-on{background:linear-gradient(135deg,#10b981 0%,#059669 100%);}";
  html += ".pill-off{background:linear-gradient(135deg,#ef4444 0%,#dc2626 100%);}";

  // ========== Relays header row ==========
  html += ".relays-title{display:flex;align-items:center;justify-content:space-between;margin:6px 2px 12px;font-size:14px;font-weight:700;color:#e8eef5;}";
  html += ".relays-title .dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#d9a45a;margin-left:6px;}";
  html += ".relays-title .counts{font-size:13px;font-weight:600;color:#9aa5b1;}";
  html += ".relays-title .counts b{color:#e3b872;}";
  html += ".relays-title .counts .off-count{color:#f87171;}";

  // ========== Master Switch Card (الكل) ==========
  html += ".master-card{display:flex;align-items:center;gap:14px;padding:16px 18px;margin-bottom:16px;}";
  html += ".master-text{flex:1;text-align:right;}";
  html += ".master-text .t1{font-size:15.5px;font-weight:800;color:#fff;}";
  html += ".master-text .t2{font-size:11.5px;color:#c9b596;margin-top:4px;}";
  html += ".master-ic{width:52px;height:52px;border-radius:50%;border:2px solid #6b5a44;display:flex;align-items:center;justify-content:center;font-size:22px;color:#a99a82;background:rgba(0,0,0,.2);flex-shrink:0;transition:all .35s;}";
  html += ".master-ic.on{border-color:#f0c479;color:#f0c479;background:radial-gradient(circle,rgba(217,164,90,.22),rgba(217,164,90,0) 70%);box-shadow:0 0 18px 4px rgba(217,164,90,.5);filter:brightness(var(--b,1));animation:togglepulse 2.2s ease-in-out infinite;}";

  // ========== Grid Cards (2 columns, like reference) ==========
  html += ".grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px;}";
  html += ".card{background:rgba(18,15,12,.62);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-radius:20px;padding:16px;border:1.5px solid rgba(217,164,90,.25);}";
  html += ".card.on{border-color:#d9a45a;background:rgba(38,28,10,.72);box-shadow:0 0 0 1px rgba(217,164,90,.3),0 0 22px rgba(217,164,90,.22);}";
  html += ".card-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;}";
  html += ".card-badge-ic{min-width:24px;height:24px;padding:0 5px;border-radius:8px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-size:12px;color:#e8dcc4;font-weight:700;}";
  html += ".card-ic{font-size:26px;margin-bottom:10px;}";
  // شكل اللمبة (أيقونة خطوط) - رمادية واقفة، وتضيء صفراء لما المفتاح يكون شغال - لمفتاح 1، 2، وكل واحدة في اللمبتين بتاعة 3 و4
  html += ".bulb-ic{width:44px;height:44px;margin:2px auto 8px;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.38);transition:color .3s,filter .3s;filter:brightness(var(--b,1));}";
  html += ".bulb-ic svg{width:30px;height:30px;display:block;}";
  html += ".bulb-ic.on{color:#ffe135;filter:brightness(var(--b,1)) drop-shadow(0 0 6px rgba(255,225,53,.9)) drop-shadow(0 0 14px rgba(255,225,53,.5));}";
  html += ".dualbulb-ic{display:flex;justify-content:center;align-items:center;gap:6px;margin:2px 0 8px;}";
  html += ".dualbulb-ic .bulb-ic{width:26px;height:26px;margin:0;}";
  html += ".dualbulb-ic .bulb-ic svg{width:22px;height:22px;}";
  html += ".strip-ic{width:74%;height:9px;border-radius:6px;background:linear-gradient(90deg,rgba(255,225,53,.12),#ffe135 50%,rgba(255,225,53,.12));margin:18px auto 15px;box-shadow:0 0 16px 4px rgba(255,225,53,.55);filter:brightness(var(--b,1));}";
  html += ".fairy-ic{display:flex;justify-content:center;align-items:flex-end;gap:13px;margin:14px 0 14px;}";
  html += ".fairy-ic span{width:11px;height:11px;border-radius:50%;background:radial-gradient(circle,#fff6d8,#f0a840 70%);box-shadow:0 0 10px 3px rgba(240,168,64,.65);display:inline-block;filter:brightness(var(--b,1));}";
  html += ".card-name{font-size:15px;font-weight:700;color:#f0f0f0;}";
  html += ".card-sub{font-size:11.5px;color:#8a96a3;margin-top:2px;margin-bottom:14px;}";
  html += ".card-badge{display:inline-block;font-size:10px;background:rgba(102,126,234,.2);color:#a5b4fc;padding:3px 8px;border-radius:10px;margin:2px 0 8px;font-weight:600;}";
  html += ".card-bottom{display:flex;align-items:center;justify-content:space-between;}";
  html += ".card-state{font-size:12px;font-weight:700;color:#8a96a3;letter-spacing:.5px;}";
  html += ".card.on .card-state{color:#e3b872;}";

  // ========== Toggle Switch (illuminated / neon look) ==========
  html += ".toggle{width:56px;height:32px;border-radius:18px;background:#161c26;border:1.5px solid #2a3648;position:relative;cursor:pointer;flex-shrink:0;box-shadow:inset 0 2px 6px rgba(0,0,0,.55);transition:background .35s,border-color .35s,box-shadow .35s;}";
  html += ".toggle::after{content:'';position:absolute;top:3px;left:3px;width:24px;height:24px;background:radial-gradient(circle at 35% 30%,#8b97a8,#4b5563);border-radius:50%;transition:left .3s ease,background .3s;box-shadow:0 1px 3px rgba(0,0,0,.5);}";
  html += ".toggle.on{background:linear-gradient(135deg,#f0c479,#c9862f);border-color:#f0c479;box-shadow:inset 0 1px 3px rgba(255,255,255,.25),0 0 10px 2px rgba(217,164,90,.55),0 0 22px 4px rgba(217,164,90,.28);filter:brightness(var(--b,1));animation:togglepulse 2.2s ease-in-out infinite;}";
  html += ".toggle.on::after{left:27px;background:radial-gradient(circle at 35% 30%,#ffffff,#fff2d8);box-shadow:0 0 8px 3px rgba(255,255,255,.9);}";
  html += "@keyframes togglepulse{0%,100%{box-shadow:inset 0 1px 3px rgba(255,255,255,.25),0 0 10px 2px rgba(217,164,90,.5),0 0 20px 4px rgba(217,164,90,.25)}50%{box-shadow:inset 0 1px 3px rgba(255,255,255,.35),0 0 16px 4px rgba(217,164,90,.75),0 0 30px 8px rgba(217,164,90,.4)}}";

  // ========== Sections ==========
  html += ".section{background:rgba(18,15,12,.62);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-radius:20px;padding:20px;margin:16px 0;border:1.5px solid rgba(217,164,90,.25);}";
  html += ".section h2{margin-top:0;font-size:16px;color:#e3b872;font-weight:800;margin-bottom:10px;}";
  html += ".section p{color:#d8cdb9;font-size:14px;line-height:1.8;margin:8px 0;}";
  html += ".info-box{background:rgba(217,164,90,.1);border-radius:14px;padding:14px 16px;font-size:13.5px;color:#d8cdb9;margin:12px 0;border-left:4px solid #d9a45a;line-height:1.7;}";

  // ========== Emergency Alert ==========
  html += ".emergency-alert{background:linear-gradient(135deg,#dc2626 0%,#991b1b 100%);border-radius:20px;padding:18px;margin-bottom:16px;border:2px solid #ef4444;}";
  html += ".emergency-alert h2{color:#fecaca;margin-bottom:8px;}";
  html += ".emergency-alert p{color:#fee2e2;}";

  // ========== Forms & Inputs ==========
  html += "input[type=text],input[type=password],input[type=number],input[type=email]{width:100%;padding:13px 15px;margin:8px 0;border-radius:14px;border:1.5px solid #2a3a4a;background:#0d0f14;color:#e8eef5;font-size:15px;font-family:inherit;}";
  html += "input:focus{outline:none;border-color:#a78bfa;}";
  html += "input::placeholder{color:#7a8a9a;}";

  html += ".btn{display:block;width:100%;margin:10px 0;padding:15px;border:none;border-radius:16px;font-size:16px;font-weight:700;cursor:pointer;text-decoration:none;text-align:center;color:#fff;}";
  html += ".btn-green{background:linear-gradient(135deg,#10b981 0%,#059669 100%);}";
  html += ".btn-red{background:linear-gradient(135deg,#ef4444 0%,#dc2626 100%);}";
  html += ".btn-blue{background:linear-gradient(135deg,#3b82f6 0%,#1d4ed8 100%);}";
  html += ".btn-orange{background:linear-gradient(135deg,#f97316 0%,#ea580c 100%);}";
  html += ".btn-purple{background:linear-gradient(135deg,#a855f7 0%,#7e22ce 100%);}";

  // ========== Checkboxes & Rows ==========
  html += ".checkrow{display:flex;align-items:center;gap:10px;color:#d1d5db;font-size:14px;margin:10px 0;padding:8px;}";
  html += "input[type=checkbox]{width:18px;height:18px;cursor:pointer;accent-color:#a78bfa;}";

  // ========== WiFi Scan Results ==========
  html += ".wifiItem{display:flex;justify-content:space-between;align-items:center;background:#0d0f14;border:1.5px solid #2a3a4a;border-radius:14px;padding:12px 15px;margin:8px 0;cursor:pointer;font-size:14px;color:#e8eef5;transition:border-color .15s;}";
  html += ".wifiItem:hover,.wifiItem:active{border-color:#a78bfa;}";
  html += ".wifiItem .netName{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:70%;}";
  html += ".wifiItem .netMeta{color:#7a8a9a;font-size:12px;flex-shrink:0;}";

  // ========== Topics Display ==========
  html += ".topics{text-align:right;background:rgba(217,164,90,.1);border-radius:14px;padding:16px;font-size:13.5px;color:#d1d5db;line-height:2.2;border-left:4px solid #d9a45a;}";
  html += ".topics span{color:#a78bfa;font-weight:700;}";

  // ========== Brightness / Dimming Slider ==========

  // ========== Bottom Navigation (with floating center Edit button) ==========
  html += ".bottomnav{position:fixed;left:14px;right:14px;bottom:14px;background:rgba(18,15,12,.78);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);display:flex;justify-content:space-around;align-items:flex-end;padding:10px 8px;border-radius:28px;border:1.5px solid rgba(217,164,90,.25);z-index:10;}";
  html += ".navitem{color:#a99a82;text-decoration:none;text-align:center;font-size:11px;flex:1;font-weight:600;}";
  html += ".navitem .ic{display:flex;align-items:center;justify-content:center;width:36px;height:36px;margin:0 auto 4px;font-size:17px;border-radius:50%;}";
  html += ".navitem.active{color:#e3b872;position:relative;}";
  html += ".navitem.active .ic{background:linear-gradient(135deg,#8a5a26,#d9a45a);}";
  html += ".navitem.active::after{content:'';display:block;width:16px;height:2.5px;background:#e3b872;border-radius:2px;margin:4px auto 0;}";

  // ========== Footer ==========
  html += "footer{color:#6b7280;margin:24px 0 14px;font-size:12px;text-align:center;line-height:1.8;}";
  html += "footer a{color:#a78bfa;text-decoration:none;font-weight:600;}";

  // ========== Responsive ==========
  html += "@media(max-width:360px){.grid{grid-template-columns:1fr;}}";

  html += "</style>";
  html += "<script>";
  html += "function confirmGo(msg,url){if(confirm(msg)){window.location.href=url;}return false;}";
  html += "function toggleRelay(relay,state){sessionStorage.setItem('scrollY',window.scrollY);fetch('/control?relay='+relay+'&state='+state).then(function(){window.location.href='/';});}";
  html += "window.addEventListener('load',function(){var y=sessionStorage.getItem('scrollY');if(y!==null){window.scrollTo(0,parseInt(y));sessionStorage.removeItem('scrollY');}});";
  html += "function openDrawer(){document.getElementById('drw').classList.add('open');document.getElementById('drwov').classList.add('open');}";
  html += "function closeDrawer(){document.getElementById('drw').classList.remove('open');document.getElementById('drwov').classList.remove('open');}";
  html += "function scanWifi(btn){";
  html += "btn.disabled=true;btn.innerText='🔄 جاري البحث عن الشبكات...';";
  html += "var box=document.getElementById('scanResults');";
  html += "box.innerHTML='<p style=\"color:#9aa5b1;font-size:13px;\">بيدور على الشبكات القريبة...</p>';";
  html += "fetch('/scanwifi').then(function(r){return r.json();}).then(function(list){";
  html += "btn.disabled=false;btn.innerText='🔍 Scan for Networks';";
  html += "if(!list.length){box.innerHTML='<p style=\"color:#9aa5b1;font-size:13px;\">مفيش شبكات ظاهرة، جرب تاني</p>';return;}";
  html += "var h='';";
  html += "list.forEach(function(net){";
  html += "var safe=net.ssid.replace(/\\\\/g,'\\\\\\\\').replace(/'/g,\"\\\\'\");";
  html += "h+='<div class=\"wifiItem\" onclick=\"pickWifi(\\''+safe+'\\')\"><span class=\"netName\">'+(net.secure?'🔒 ':'🔓 ')+net.ssid+'</span><span class=\"netMeta\">'+net.rssi+' dBm</span></div>';";
  html += "});";
  html += "box.innerHTML=h;";
  html += "}).catch(function(){btn.disabled=false;btn.innerText='🔍 Scan for Networks';box.innerHTML='<p style=\"color:#e6544a;font-size:13px;\">فشل البحث، حاول تاني</p>';});";
  html += "}";
  html += "function pickWifi(ssid){document.getElementById('ssidInput').value=ssid;document.getElementById('passInput').focus();}";
  html += "</script>";
  html += "</head><body style='--b:" + String((float)globalBrightness / 100.0, 2) + ";'>";

  // ========== Side Drawer (زرار الهمبرجر) ==========
  html += "<div class='drawer-overlay' id='drwov' onclick='closeDrawer()'></div>";
  html += "<div class='drawer' id='drw'>";
  html += "<button class='drawer-close' onclick='closeDrawer()'>✕</button>";
  html += "<h3>" + panelTitle + "</h3>";
  html += "<a href='/'><span class='dic'>🏠</span>الرئيسية</a>";
  html += "<a href='/schedule'><span class='dic'>⏰</span>تايمر المواعيد</a>";
  html += "<a href='/emergency'><span class='dic'>🚨</span>الطوارئ</a>";
  html += "<a href='/relaynames'><span class='dic'>✏️</span>تعديل أسماء المفاتيح</a>";
  html += "<a href='/wifi'><span class='dic'>📶</span>إعدادات الشبكة</a>";
  html += "<a href='/mqtt'><span class='dic'>📡</span>MQTT</a>";
  html += "<a href='/system'><span class='dic'>⚙️</span>System</a>";
  if (peerBoardUrl.length() > 0) {
    html += "<a href='http://" + peerBoardUrl + "/'><span class='dic'>🔀</span>البورد التاني</a>";
  }
  html += "<a href='javascript:void(0)' onclick=\"return confirmGo('هل تريد إعادة تشغيل الجهاز؟','/restart')\"><span class='dic'>🔄</span>Restart</a>";
  html += "</div>";

  // ========== Hero Section ==========
  html += "<div class='hero'>";
  html += "<div class='topbar'>";
  html += "<a href='javascript:void(0)' class='iconbtn' onclick='openDrawer()' title='القائمة'>☰</a>";
  html += "<svg class='house-wifi' viewBox='0 0 48 44' fill='none' xmlns='http://www.w3.org/2000/svg'>";
  html += "<path d='M6 22 L24 6 L42 22' stroke='currentColor' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'/>";
  html += "<path d='M11 26 L11 40 L20 40 L20 30 L28 30 L28 40 L37 40 L37 26' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'/>";
  html += "<path d='M18 3 Q24 -2 30 3' stroke='currentColor' stroke-width='2' stroke-linecap='round'/>";
  html += "<path d='M21 6.5 Q24 4 27 6.5' stroke='currentColor' stroke-width='2' stroke-linecap='round'/>";
  html += "<circle cx='24' cy='9' r='1.4' fill='currentColor'/>";
  html += "</svg>";
  html += "<a href='/wifi' class='iconbtn' title='الإعدادات'>⚙️</a>";
  html += "</div>";

  html += "<h1>" + panelTitle + "</h1>";
  html += "<div class='online-pill'><span class='dot'></span><span>ONLINE</span></div>";
  html += "</div>";

  return html;
}

// ============================================================
//                   Bottom Navigation
// ============================================================
String bottomNav(String active) {
  String html = "<div class='bottomnav'>";
  html += "<a class='navitem" + String(active == "home" ? " active" : "") + "' href='/'><span class='ic'>🏠</span>الرئيسية</a>";
  html += "<a class='navitem" + String(active == "wifi" ? " active" : "") + "' href='/wifi'><span class='ic'>📶</span>الشبكة</a>";
  html += "<a class='navitem" + String(active == "names" ? " active" : "") + "' href='/relaynames'><span class='ic'>✏️</span>تعديل</a>";
  html += "<a class='navitem" + String(active == "mqtt" ? " active" : "") + "' href='/mqtt'><span class='ic'>📡</span>MQTT</a>";
  html += "<a class='navitem' href='javascript:void(0)' onclick=\"return confirmGo('هل تريد إعادة تشغيل الجهاز؟','/restart')\"><span class='ic'>🔄</span>Restart</a>";
  html += "</div>";
  return html;
}

// ============================================================
//                   HTML Footer
// ============================================================
String htmlFooter(String active) {
  String html = bottomNav(active);
  html += "<footer>";
  html += "© 2026 <strong>Mostafa Badawy Controller v2.0</strong><br>";
  html += "📧 mostafabadwy12@gmail.com | 📱 +201066339340<br>";
  html += "<a href='#'>Privacy</a> • <a href='#'>Support</a>";
  html += "</footer>";
  html += "</body></html>";
  return html;
}

// ============================================================
//                       صفحة Home
// ============================================================
// خلفية المطبخ (بار المطبخ) - بتتقرأ من الفلاش مباشرة وبتترسل زي ما هي كصورة، مش جوه الـ HTML
// عشان متستهلكش رامات الجهاز في كل طلب صفحة
void handleBgImage() {
  server.sendHeader("Cache-Control", "public, max-age=604800, immutable");
  server.send_P(200, "image/jpeg", (PGM_P)BG_IMAGE, BG_IMAGE_LEN);
}

void handleRoot() {
  bool anyTimerActive = false;
  for (int i = 0; i < RELAY_COUNT; i++) {
    if (relayIsTimer[i] && relayState[i]) anyTimerActive = true;
  }

  String html = htmlHeader(panelTitle);
  html += lightspotsHtml();
  if (anyTimerActive) {
    // لو فيه مفتاح تايمر شغال، حدّث الصفحة بعد ثانيتين عشان الشكل يتزامن مع الحالة الفعلية
    html.replace("</head>", "<meta http-equiv='refresh' content='2'></head>");
  }
  html += "<div class='container'>";

  if (emergencyActive) {
    html += "<div class='section' style='border-color:#e6544a;background:#2a1210;'>";
    html += "<h2 style='color:#ff8a80;margin:0 0 6px;'>🚨 وضع الطوارئ شغال دلوقتي</h2>";
    html += "<a href='/emergency' class='btn btn-red'>عرض التفاصيل / إيقاف</a>";
    html += "</div>";
  }

  bool allOn = true;
  for (int i = 0; i < RELAY_COUNT; i++) if (!relayState[i]) { allOn = false; break; }

  html += "<div class='card master-card" + String(allOn ? " on" : "") + "'>";
  html += "<div class='toggle" + String(allOn ? " on" : "") + "' onclick=\"toggleRelay('all','" + String(allOn ? "off" : "on") + "')\"></div>";
  html += "<div class='master-text'><div class='t1'>المفتاح الرئيسي (الكل)</div><div class='t2'>🏠 تشغيل / إيقاف كل المفاتيح</div></div>";
  html += "<div class='master-ic" + String(allOn ? " on" : "") + "'><svg width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'><path d='M18.36 6.64a9 9 0 1 1-12.73 0'></path><line x1='12' y1='2' x2='12' y2='12'></line></svg></div>";
  html += "</div>";

  if (!emergencyButtonEnabled) {
    html += "<div class='section' style='padding:10px 16px;margin-bottom:10px;border-color:#8a96a3;background:#1a2129;'>";
    html += "<a href='/emergency' style='color:#8a96a3;text-decoration:none;'>⚪ زرار الطوارئ الفيزيائي متعطّل حاليًا (وضع أنا موجود في البيت)</a>";
    html += "</div>";
  }

  int onCount = 0;
  for (int i = 0; i < RELAY_COUNT; i++) if (relayState[i]) onCount++;
  html += "<div class='relays-title'><span><span class='dot'></span>الريلايات</span>";
  html += "<span class='counts'>تشغيل <b>" + String(onCount) + "</b> | إيقاف <b class='off-count'>" + String(RELAY_COUNT - onCount) + "</b></span></div>";

  html += "<div class='grid'>";
  for (int i = 0; i < RELAY_COUNT; i++) {
    bool st = relayState[i];
    String nm = relayNames[i];
    html += "<div class='card" + String(st ? " on" : "") + "'>";
    html += "<div class='card-top'><span class='card-badge-ic'>" + cardTopLeftBadge(i, nm) + "</span><span class='card-badge-ic'>" + cardTopRightBadge(nm) + "</span></div>";
    html += cardMainVisual(i, nm, st);
    html += "<div class='card-name'>" + nm + "</div>";
    if (relayIsTimer[i]) html += "<div class='card-badge'>⏱ Timer 1s</div>";
    else html += "<div class='card-sub'>&nbsp;</div>";
    html += "<div class='card-bottom'>";
    html += "<span class='card-state'>" + String(st ? "ON" : "OFF") + "</span>";
    html += "<div class='toggle" + String(st ? " on" : "") + "' onclick=\"toggleRelay(" + String(i) + ",'" + String(st ? "off" : "on") + "')\"></div>";
    html += "</div>";
    html += "</div>";
  }
  html += "</div>"; // grid

  html += "<div class='section' style='padding:14px 16px;margin-bottom:10px;'>";
  html += "<a href='/schedule' class='btn btn-purple' style='margin:0;'>⏰ تايمر المواعيد (لكل كشاف)" + String(anyScheduleEnabled() ? " - شغال ✅" : "") + "</a>";
  html += "</div>";

  html += "</div>"; // container
  html += htmlFooter("home");
  server.send(200, "text/html", html);
}

void handleControl() {
  String relay = server.arg("relay");
  String state = server.arg("state");
  bool st = (state == "on");

  if (relay == "all") {
    setAllRelays(st);
  } else {
    int idx = relay.toInt();
    setRelay(idx, st);
  }

  server.send(200, "text/plain", "OK");
}

void handleSetBrightness() {
  int val = server.arg("value").toInt();
  if (val < 10) val = 10;   // منمنعش توصل صفر عشان الشكل ميختفيش خالص
  if (val > 100) val = 100;
  globalBrightness = val;
  saveBrightness(val);
  server.send(200, "text/plain", "OK");
}

// ============================================================
//                       بحث عن شبكات الواي فاي القريبة
// ============================================================
void handleScanWifi() {
  int n = WiFi.scanNetworks();

  // تجميع النتائج مع إزالة تكرار نفس اسم الشبكة (بيحصل لو فيه أكتر من راوتر
  // بنفس الاسم)، وبناخد أقوى إشارة لكل اسم.
  const int MAX_NETS = 40;
  String names[MAX_NETS];
  int32_t rssis[MAX_NETS];
  bool secure[MAX_NETS];
  int count = 0;

  for (int i = 0; i < n && count < MAX_NETS; i++) {
    String ssid = WiFi.SSID(i);
    if (ssid.length() == 0) continue; // تجاهل الشبكات المخفية من غير اسم ظاهر
    int existing = -1;
    for (int j = 0; j < count; j++) {
      if (names[j] == ssid) { existing = j; break; }
    }
    if (existing >= 0) {
      if (WiFi.RSSI(i) > rssis[existing]) rssis[existing] = WiFi.RSSI(i);
    } else {
      names[count] = ssid;
      rssis[count] = WiFi.RSSI(i);
      secure[count] = (WiFi.encryptionType(i) != WIFI_AUTH_OPEN);
      count++;
    }
  }

  // ترتيب تنازلي حسب قوة الإشارة (الأقوى فوق) — العدد صغير فمفيش داعي لخوارزمية معقدة
  for (int i = 0; i < count - 1; i++) {
    for (int j = 0; j < count - i - 1; j++) {
      if (rssis[j] < rssis[j + 1]) {
        int32_t tr = rssis[j]; rssis[j] = rssis[j + 1]; rssis[j + 1] = tr;
        String tn = names[j]; names[j] = names[j + 1]; names[j + 1] = tn;
        bool ts = secure[j]; secure[j] = secure[j + 1]; secure[j + 1] = ts;
      }
    }
  }

  DynamicJsonDocument doc(4096);
  JsonArray arr = doc.to<JsonArray>();
  for (int i = 0; i < count; i++) {
    JsonObject o = arr.createNestedObject();
    o["ssid"] = names[i];
    o["rssi"] = rssis[i];
    o["secure"] = secure[i];
  }

  String json;
  serializeJson(doc, json);
  WiFi.scanDelete();
  server.send(200, "application/json", json);
}

// ============================================================
//                       صفحة WiFi Settings
// ============================================================
void handleWifiPage() {
  String html = htmlHeader("WiFi Settings");
  html += "<div class='container'>";

  html += "<div class='section'><h2>📶 Current Connection Status</h2>";
  html += "<p>Status: " + String(WiFi.status() == WL_CONNECTED ? "✅ Connected" : "❌ Not Connected") + "<br>";
  html += "Network: " + (staSsid.length() ? staSsid : String("--")) + "<br>";
  html += "IP: " + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("--")) + "</p></div>";

  html += "<div class='section' style='border-color:#1fb87a;background:#0f2016;'><h2>📡 Access Point (Always Available)</h2>";
  html += "<p>Network Name: " + apSsid + "<br>";
  html += "Password: " + apPass + "<br>";
  html += "Network Status: " + String(apHidden ? "🙈 Hidden" : "👁 Visible") + "<br>";
  html += "AP IP: <b>192.168.4.1</b></p></div>";

  html += "<div class='section'><h2>✏️ Enter Network Details Manually</h2>";
  html += "<button type='button' class='btn btn-blue' onclick='scanWifi(this)'>🔍 Scan for Networks</button>";
  html += "<div id='scanResults'></div>";
  html += "<form action='/savewifi' method='POST'>";
  html += "<input type='text' name='ssid' id='ssidInput' placeholder='Network name (SSID)' value='" + staSsid + "'>";
  html += "<input type='password' name='pass' id='passInput' placeholder='Password'>";
  html += "<button class='btn btn-green' type='submit'>💾 Save and connect</button>";
  html += "</form></div>";

  html += "<div class='section'><h2>📡 Configure Access Point</h2>";
  html += "<form action='/saveap' method='POST'>";
  html += "<input type='text' name='apssid' placeholder='Network name' value='" + apSsid + "'>";
  html += "<input type='password' name='appass' placeholder='Password' value='" + apPass + "'>";
  html += "<input type='password' name='appass2' placeholder='Confirm AP Password'>";
  html += "<div class='checkrow'><input type='checkbox' name='hidden' id='hd' " + String(apHidden ? "checked" : "") + "><label for='hd'>🔒 Hide network name</label></div>";
  html += "<button class='btn btn-green' type='submit'>💾 Save AP Settings</button>";
  html += "</form></div>";

  html += "<div class='section'><h2>📌 IP ثابت للبورد (Static IP)</h2>";
  html += "<p>لو مفعّل، البورد هياخد نفس الـ IP دا كل مرة بدل ما يتغير من الروتر. لازم البيانات تكون متوافقة مع شبكتك (مثلاً لو الروتر 192.168.1.1، اكتب Gateway = 192.168.1.1 و IP من نفس الرينج زي 192.168.1.200).</p>";
  html += "<form action='/savestaticip' method='POST'>";
  html += "<div class='checkrow'><input type='checkbox' name='sipen' id='sipen' " + String(staUseStaticIp ? "checked" : "") + "><label for='sipen'>📌 تفعيل IP ثابت</label></div>";
  html += "<input type='text' name='sipip' placeholder='IP الثابت (مثال: 192.168.1.200)' value='" + staStaticIp + "'>";
  html += "<input type='text' name='sipgw' placeholder='Gateway (عادة IP الروتر، مثال: 192.168.1.1)' value='" + staStaticGateway + "'>";
  html += "<input type='text' name='sipsub' placeholder='Subnet Mask' value='" + staStaticSubnet + "'>";
  html += "<input type='text' name='sipdns' placeholder='DNS (اختياري، سيبه فاضي لو مش عارف)' value='" + staStaticDns + "'>";
  html += "<button class='btn btn-green' type='submit'>💾 حفظ وإعادة الاتصال</button>";
  html += "</form></div>";

  html += "<div class='section'><h2>🔀 بورد تاني على نفس الشبكة</h2>";
  html += "<p>سيب الحقل فاضي لو مش عايز الأيقونة، أو اكتب آي بي البورد التاني (تقدر تشوفه من System Info بتاعه) عشان تظهرلك أيقونة تنقل بينهم في كل صفحة.</p>";
  html += "<form action='/savepeer' method='POST'>";
  html += "<input type='text' name='peerip' placeholder='مثال: 192.168.1.50' value='" + peerBoardUrl + "'>";
  html += "<button class='btn btn-green' type='submit'>💾 حفظ</button>";
  html += "</form></div>";

  html += "<div class='section'><h2>⚙️ Other Settings</h2>";
  html += "<a href='/sysinfo' class='btn btn-blue'>ℹ️ System Info</a>";
  html += "<a href='/emergency' class='btn btn-red'>🚨 Emergency Button Settings</a>";
  html += "<a href='/system' class='btn btn-purple'>🛠️ System (OTA / Backup / Restore)</a>";
  html += "<a href='javascript:void(0)' onclick=\"return confirmGo('هل تريد مسح كل الإعدادات المحفوظة؟','/clearsettings')\" class='btn btn-red'>🗑 Clear saved settings</a>";
  html += "<a href='javascript:void(0)' onclick=\"return confirmGo('هل تريد إعادة تشغيل الجهاز؟','/restart')\" class='btn btn-blue'>🔄 Restart device</a>";
  html += "<a href='/currentip' class='btn btn-blue'>🌐 Current IP Settings</a>";
  html += "</div>";

  html += "</div>";

  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

void handleSavePeer() {
  peerBoardUrl = server.arg("peerip");
  peerBoardUrl.trim();
  savePeerBoard(peerBoardUrl);
  server.sendHeader("Location", "/wifi");
  server.send(303);
}

void handleSaveStaticIp() {
  bool en = server.hasArg("sipen");
  String ip  = server.arg("sipip");
  String gw  = server.arg("sipgw");
  String sub = server.arg("sipsub");
  String dns = server.arg("sipdns");
  ip.trim(); gw.trim(); sub.trim(); dns.trim();
  if (sub.length() == 0) sub = "255.255.255.0";

  IPAddress tmp;
  bool ipValid = tmp.fromString(ip);
  bool gwValid = tmp.fromString(gw);

  if (en && (!ipValid || !gwValid)) {
    server.send(200, "text/html", htmlHeader("خطأ") + "<div class='container'><div class='section'><h2>❌ الـ IP أو الـ Gateway اللي كتبته مش صحيح</h2><a href='/wifi' class='btn btn-blue'>رجوع</a></div></div>" + htmlFooter("wifi"));
    return;
  }

  staUseStaticIp   = en;
  staStaticIp      = ip;
  staStaticGateway = gw;
  staStaticSubnet  = sub;
  staStaticDns     = dns;
  saveStaticIpSettings(en, ip, gw, sub, dns);

  server.send(200, "text/html", htmlHeader("تم الحفظ") + "<div class='container'><div class='section'><h2>تم الحفظ، جاري إعادة الاتصال...</h2></div></div>" + htmlFooter("wifi"));
  delay(500);
  connectToWifi();
}

void handleSaveWifi() {
  String ssid = server.arg("ssid");
  String pass = server.arg("pass");
  if (ssid.length() > 0) {
    staSsid = ssid;
    staPass = pass;
    saveWifiSettings(ssid, pass);
  }
  server.send(200, "text/html", htmlHeader("Saved") + "<div class='container'><div class='section'><h2>تم الحفظ، جاري الاتصال بالشبكة...</h2></div></div>" + htmlFooter("wifi"));
  delay(500);
  connectToWifi();
}

void handleSaveAp() {
  String ssid = server.arg("apssid");
  String pass = server.arg("appass");
  String pass2 = server.arg("appass2");
  bool hidden = server.hasArg("hidden");

  if (pass2.length() > 0 && pass2 != pass) {
    server.send(200, "text/html", htmlHeader("خطأ") + "<div class='container'><div class='section'><h2>كلمة السر غير متطابقة</h2><a href='/wifi' class='btn btn-blue'>رجوع</a></div></div>" + htmlFooter("wifi"));
    return;
  }

  if (ssid.length() > 0 && pass.length() >= 8) {
    apSsid = ssid;
    apPass = pass;
    apHidden = hidden;
    saveApSettings(ssid, pass, hidden);
  }
  server.sendHeader("Location", "/wifi");
  server.send(303);
}

void handleClearSettings() {
  clearAllSettings();
  server.send(200, "text/html", htmlHeader("تم المسح") + "<div class='container'><div class='section'><h2>تم مسح كل الإعدادات، جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("wifi"));
  delay(1500);
  ESP.restart();
}

void handleCurrentIp() {
  String html = htmlHeader("Current IP Settings");
  html += "<div class='container'><div class='section'>";
  html += "<p>STA IP: " + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("--")) + "<br>";
  html += "نوع الـ IP: " + String(staUseStaticIp ? "📌 ثابت (Static)" : "🔄 تلقائي من الروتر (DHCP)") + "<br>";
  html += "Gateway: " + (WiFi.status() == WL_CONNECTED ? WiFi.gatewayIP().toString() : String("--")) + "<br>";
  html += "Subnet: " + (WiFi.status() == WL_CONNECTED ? WiFi.subnetMask().toString() : String("--")) + "<br>";
  html += "AP IP: " + WiFi.softAPIP().toString() + "<br>";
  html += "MAC: " + WiFi.macAddress() + "</p></div>";
  html += "<a href='/wifi' class='btn btn-blue'>⬅ رجوع</a></div>";
  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

// ============================================================
//                       صفحة Edit Names + Timer
// ============================================================
void handleRelayNamesPage() {
  String html = htmlHeader("Edit Names");
  html += "<div class='container'>";

  html += "<div class='section'><h2>🏷️ Panel Title</h2>";
  html += "<form action='/savetitle' method='POST'>";
  html += "<input type='text' name='title' value='" + panelTitle + "'>";
  html += "<button class='btn btn-purple' type='submit'>💾 Save Title</button>";
  html += "</form></div>";

  html += "<div class='section'><h2>✏️ Change Device Names</h2>";
  html += "<p>غيّر اسم أي ريليه، وحدد لو عايزه يشتغل كـ تايمر 1 ثانية (بيقفل نفسه تلقائي بعد التشغيل)</p>";
  html += "<form action='/saverelaynames' method='POST'>";

  for (int i = 0; i < RELAY_COUNT; i++) {
    html += "<h3 style='color:#7fd1ff;font-size:14px;margin-bottom:4px;'>🔷 Relay " + String(i + 1) + "</h3>";
    html += "<input type='text' name='name" + String(i) + "' value='" + relayNames[i] + "'>";
    html += "<div class='checkrow'><input type='checkbox' name='timer" + String(i) + "' id='t" + String(i) + "' " + String(relayIsTimer[i] ? "checked" : "") + ">";
    html += "<label for='t" + String(i) + "'>⏱ تفعيل وضع التايمر (1 ثانية) لهذا المفتاح</label></div>";
  }

  html += "<p style='color:#8a96a3;font-size:12.5px;'><b>ملاحظة:</b> بعد حفظ الأسماء، الصفحة الرئيسية هتتحدث تلقائي</p>";
  html += "<button class='btn btn-green' type='submit'>💾 Save New Names</button>";
  html += "</form></div>";

  html += "</div>";
  html += htmlFooter("names");
  server.send(200, "text/html", html);
}

void handleSaveRelayNames() {
  for (int i = 0; i < RELAY_COUNT; i++) {
    String nameKey = "name" + String(i);
    String timerKey = "timer" + String(i);
    if (server.hasArg(nameKey)) {
      String val = server.arg(nameKey);
      if (val.length() > 0) relayNames[i] = val;
    }
    relayIsTimer[i] = server.hasArg(timerKey);
  }
  saveRelayNamesAndTimers();
  publishDiscovery(); // أسماء المفاتيح اتغيرت، لازم نبعت رسالة اكتشاف جديدة موقّعة عليها
  server.sendHeader("Location", "/");
  server.send(303);
}

void handleSaveTitle() {
  String title = server.arg("title");
  if (title.length() > 0) {
    panelTitle = title;
    savePanelTitle(title);
    publishDiscovery(); // اسم البورد اتغير، لازم نبعت رسالة اكتشاف جديدة موقّعة عليها
  }
  server.sendHeader("Location", "/relaynames");
  server.send(303);
}

// ============================================================
//                       صفحة MQTT Settings
// ============================================================
void handleMqttPage() {
  String html = htmlHeader("MQTT Settings");
  html += "<div class='container'>";

  bool mqttOk = mqttClient.connected();
  html += "<div class='section' style='border-color:" + String(mqttOk ? "#1fb87a" : "#e6544a") +
          ";background:" + String(mqttOk ? "#0f2016" : "#2a1414") + ";'>";
  html += "<h2>" + String(mqttOk ? "✅ متصل بالبروكر" : "❌ مش متصل بالبروكر") + "</h2>";
  html += "<p>Broker: " + (mqttBroker.length() ? mqttBroker : String("--")) + ":" + String(mqttPort) + "<br>";
  html += "Prefix: " + mqttPrefix + "<br>";
  html += "مفتاح الربط: " + String(pairingKey.length() > 0 ? "✅ متحط" : "⚠️ لسه مش متحط") + "<br>";
  html += "توبيك الاكتشاف اللي التطبيق بيسمع عليه: <span style='color:#a78bfa;'>" + topicDiscovery() + "</span></p>";
  if (!mqttOk) {
    html += "<p style='color:#fca5a5;'>لازم يبقى متصل بالبروكر وحاطط مفتاح الربط عشان تقدر تكتشف البورد وتضيفه من التطبيق.</p>";
  } else if (pairingKey.length() == 0) {
    html += "<p style='color:#fbbf24;'>حط مفتاح الربط تحت وسيب البورد يعيد التشغيل، وهيبدأ يبعت رسالة اكتشاف يقدر التطبيق يلاقيها.</p>";
  } else {
    html += "<p style='color:#86efac;'>البورد جاهز — افتح التطبيق ودوس \"بورد جديد\" عشان يكتشفه أوتوماتيك.</p>";
  }
  html += "</div>";

  html += "<div class='section'><h2>📡 Configure MQTT Broker</h2>";
  html += "<div class='info-box'>ℹ️ هذه الإعدادات تتحكم في اتصال MQTT. التغييرات تسري بعد إعادة التشغيل.</div>";
  html += "<form action='/savemqtt' method='POST'>";
  html += "<input type='text' name='broker' value='" + mqttBroker + "' placeholder='Broker address'>";
  html += "<input type='text' name='prefix' value='" + mqttPrefix + "' placeholder='Topic Prefix'>";
  html += "<input type='number' name='port' value='" + String(mqttPort) + "' placeholder='Port'>";

  html += "<hr style='border-color:rgba(217,164,90,.25);margin:18px 0;'>";
  html += "<label style='display:block;color:#d1d5db;font-size:13.5px;margin-bottom:8px;'>🔑 مفتاح الربط (Pairing Key) — نفس المفتاح المكتوب في إعدادات التطبيق بالظبط:</label>";
  html += "<input type='text' name='pairingkey' value='" + pairingKey + "' placeholder='مفتاح الربط'>";
  html += "<div class='info-box'>ℹ️ المفتاح ده بيخلي التطبيق يتأكد إن البورد ده هو بتاعك فعلاً قبل ما يضيفه. اكتب أي نص سري تختاره، وحط نفس النص بالظبط في إعدادات الاتصال بالتطبيق.</div>";

  html += "<div class='topics'><b>Topics format:</b><br>";
  html += "Control: <span>" + mqttPrefix + "/control/relay1</span><br>";
  html += "Status: <span>" + mqttPrefix + "/status/relay1</span><br>";
  html += "Control All: <span>" + mqttPrefix + "/control/all</span><br>";
  html += "Status All: <span>" + mqttPrefix + "/status/all</span><br>";
  html += "Emergency (ON/OFF): <span>" + mqttPrefix + "/control/emergency</span><br>";
  html += "Emergency Button Enable (ON/OFF): <span>" + mqttPrefix + "/control/emergencybutton</span><br>";
  html += "Emergency Button Status: <span>" + mqttPrefix + "/status/emergencybutton</span></div>";

  html += "<button class='btn btn-green' type='submit'>💾 Save MQTT Settings</button>";
  html += "</form></div></div>";
  html += htmlFooter("mqtt");
  server.send(200, "text/html", html);
}

void handleSaveMqtt() {
  String broker = server.arg("broker");
  String prefix = server.arg("prefix");
  int port = server.arg("port").toInt();
  String pkey = server.arg("pairingkey");

  if (broker.length() > 0) mqttBroker = broker;
  if (prefix.length() > 0) mqttPrefix = prefix;
  if (port > 0) mqttPort = port;
  pairingKey = pkey;

  saveMqttSettings(mqttBroker, mqttPrefix, mqttPort);
  savePairingKey(pairingKey);

  server.send(200, "text/html", htmlHeader("Saved") + "<div class='container'><div class='section'><h2>تم الحفظ، جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("mqtt"));
  delay(1500);
  ESP.restart();
}

// ============================================================
//                       صفحة زرار الطوارئ
// ============================================================
void handleEmergencyPage() {
  String html = htmlHeader("Emergency Button");
  if (emergencyActive) {
    html.replace("</head>", "<meta http-equiv='refresh' content='5'></head>");
  }
  html += "<div class='container'>";

  if (emergencyActive) {
    unsigned long remain = (EMERGENCY_DURATION - (millis() - emergencyStartTime)) / 1000;
    unsigned long remainMin = remain / 60;
    unsigned long remainSec = remain % 60;
    html += "<div class='section' style='border-color:#e6544a;background:#2a1210;'><h2 style='color:#ff8a80;'>🚨 وضع الطوارئ شغال</h2>";
    html += "<p>الوقت المتبقي: " + String(remainMin) + " دقيقة و" + String(remainSec) + " ثانية</p>";
    html += "<a href='javascript:void(0)' onclick=\"return confirmGo('هل تريد إيقاف وضع الطوارئ الآن؟','/cancelemergency')\" class='btn btn-red'>⛔ إيقاف الطوارئ الآن</a>";
    html += "</div>";
  } else {
    html += "<div class='section'><h2>🚨 حالة الطوارئ</h2><p>غير مفعّل حاليًا</p></div>";
  }

  html += "<div class='section'><h2>🔘 عن زرار الطوارئ</h2>";
  html += "<p>وصّل زرار فيزيائي بين البين <b>GPIO" + String(emergencyButtonPin) + "</b> والجراوند (GND). لما حد يضغطه، أول " + String(EMERGENCY_RELAY_COUNT) + " مفاتيح هتشتغل تلقائي لمدة 30 دقيقة، وهيوصلك إشعار على موبايلك في نفس اللحظة.</p>";
  html += "</div>";

  html += "<div class='section' style='" + String(emergencyButtonEnabled ? "" : "border-color:#8a96a3;background:#1a2129;") + "'>";
  html += "<h2>" + String(emergencyButtonEnabled ? "🟢 الزرار مفعّل" : "⚪ الزرار متعطّل") + "</h2>";
  if (emergencyButtonEnabled) {
    html += "<p>الزرار الفيزيائي شغال دلوقتي. لو انت موجود في البيت وعايز حد يدوس عليه غلط ميشغلش حاجة، عطّله من هنا.</p>";
    html += "<a href='javascript:void(0)' onclick=\"return confirmGo('هيتم تعطيل زرار الطوارئ الفيزيائي، متابع؟','/toggleemergencybutton')\" class='btn btn-red'>⛔ تعطيل الزرار (أنا موجود في البيت)</a>";
  } else {
    html += "<p>الزرار الفيزيائي متعطّل دلوقتي، لو حد ضغط عليه مش هيحصل حاجة. فعّله تاني وانت خارج البيت.</p>";
    html += "<a href='javascript:void(0)' onclick=\"return confirmGo('هيتم تفعيل زرار الطوارئ الفيزيائي، متابع؟','/toggleemergencybutton')\" class='btn btn-green'>✅ تفعيل الزرار تاني</a>";
  }
  html += "</div>";

  html += "<div class='section'><h2>🔔 إعدادات إشعار الموبايل (ntfy)</h2>";
  html += "<div class='info-box'>";
  html += "1) نزّل تطبيق <b>ntfy</b> من App Store أو Google Play<br>";
  html += "2) افتح التطبيق واعمل Subscribe لاسم توبيك (Topic) خاص بيك - افضل تختار اسم غريب وصعب حد يخمنه عشان محدش تاني يقدر يشوف إشعاراتك<br>";
  html += "3) اكتب نفس الاسم بالظبط هنا واحفظ";
  html += "</div>";
  html += "<form action='/savenotify' method='POST'>";
  html += "<input type='text' name='topic' placeholder='مثال: mostafa-home-alert-9821' value='" + ntfyTopic + "'>";
  html += "<button class='btn btn-green' type='submit'>💾 حفظ اسم التوبيك</button>";
  html += "</form>";
  if (ntfyTopic.length() > 0) {
    html += "<a href='/testnotify' class='btn btn-blue'>🔔 إرسال إشعار تجريبي</a>";
  }
  html += "</div>";

  if (!emergencyActive) {
    html += "<div class='section'><h2>📱 تفعيل الطوارئ من الموبايل (وانت بره البيت)</h2>";
    html += "<p>دوس على الزرار ده وانت بره البيت عشان تشغّل أول " + String(EMERGENCY_RELAY_COUNT) + " مفاتيح فورًا، بنفس تأثير الزرار الفيزيائي بالظبط.</p>";
    html += "<a href='javascript:void(0)' onclick=\"return confirmGo('هيتم تشغيل أول 4 مفاتيح فعليًا لمدة 30 دقيقة، متابع؟','/triggeremergency')\" class='btn btn-orange'>🚨 تفعيل الطوارئ الآن</a>";
    html += "</div>";
  }

  html += "</div>";
  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

void handleSaveNotify() {
  String topic = server.arg("topic");
  topic.trim();
  ntfyTopic = topic;
  saveNtfyTopic(topic);
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleTestNotify() {
  sendNtfyNotification("🔔 اختبار - " + panelTitle, "الإشعارات شغالة تمام! دي رسالة تجريبية من زرار الطوارئ.");
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleToggleEmergencyButton() {
  emergencyButtonEnabled = !emergencyButtonEnabled;
  saveEmergencyButtonEnabled(emergencyButtonEnabled);
  publishEmergencyButtonStatus();
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleTriggerEmergency() {
  activateEmergency();
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleCancelEmergency() {
  deactivateEmergency(true);
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

// ============================================================
//                 صفحة الإضاءة التلقائية (ليل/نهار)
// ============================================================
// ============================================================
//                 صفحة تايمر المواعيد (الكشاف)
// ============================================================
void handleSchedulePage() {
  String html = htmlHeader("Schedule Timer");
  html.replace("</head>", "<meta http-equiv='refresh' content='20'></head>"); // تحديث الوقت الحالي كل 20 ثانية
  html += "<div class='container'>";

  time_t t = time(nullptr);
  bool timeSynced = (t >= 1700000000);
  html += "<div class='section'><h2>🕒 الوقت الحالي</h2>";
  if (timeSynced) {
    time_t local = t + (long)schedGmtOffset * 3600L;
    struct tm *tmNow = gmtime(&local);
    char buf[32];
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", tmNow->tm_hour, tmNow->tm_min, tmNow->tm_sec);
    html += "<p>الوقت دلوقتي عند الجهاز: <b>" + String(buf) + "</b></p>";
  } else {
    html += "<p style='color:#f0a63f;'>⏳ الوقت لسه بيتزامن من الإنترنت... تأكد إن الجهاز متصل بالواي فاي (لازم إنترنت فعلي مش بس شبكة محلية)</p>";
  }
  html += "</div>";

  // إعداد التوقيت العام (مشترك لكل الجداول)
  html += "<div class='section'><h2>🌍 فرق التوقيت</h2>";
  html += "<form action='/savegmt' method='POST'>";
  html += "<p style='color:#8a96a3;font-size:12.5px;margin-bottom:0;'>فرق التوقيت عن جرينتش (مصر = 2):</p>";
  html += "<input type='number' name='gmt' min='-12' max='14' value='" + String(schedGmtOffset) + "'>";
  html += "<button class='btn btn-blue' type='submit' style='margin-top:10px;'>💾 حفظ فرق التوقيت</button>";
  html += "</form></div>";

  // جدول مستقل لكل ريليه/كشاف
  for (int i = 0; i < RELAY_COUNT; i++) {
    html += "<div class='section'><h2>⏰ " + relayNames[i] + String(schedEnabled[i] ? " - شغال ✅" : "") + "</h2>";
    if (timeSynced && schedEnabled[i]) {
      html += "<p>الحالة دلوقتي: <b>" + String(relayState[i] ? "شغال" : "مقفول") + "</b></p>";
    }
    html += "<form action='/saveschedule' method='POST'>";
    html += "<input type='hidden' name='relay' value='" + String(i) + "'>";

    html += "<div class='checkrow'><input type='checkbox' name='en' id='schen" + String(i) + "' " + String(schedEnabled[i] ? "checked" : "") + ">";
    html += "<label for='schen" + String(i) + "'>تفعيل الجدول لـ " + relayNames[i] + "</label></div>";

    html += "<p style='color:#8a96a3;font-size:12.5px;margin-bottom:4px;'>ميعاد التشغيل (الفتح):</p>";
    html += "<div style='display:flex;gap:10px;'>";
    html += "<input type='number' name='onh' min='0' max='23' value='" + String(schedOnHour[i]) + "' placeholder='ساعة' style='flex:1;'>";
    html += "<input type='number' name='onm' min='0' max='59' value='" + String(schedOnMinute[i]) + "' placeholder='دقيقة' style='flex:1;'>";
    html += "</div>";

    html += "<p style='color:#8a96a3;font-size:12.5px;margin-bottom:4px;'>ميعاد الإيقاف (القفل):</p>";
    html += "<div style='display:flex;gap:10px;'>";
    html += "<input type='number' name='offh' min='0' max='23' value='" + String(schedOffHour[i]) + "' placeholder='ساعة' style='flex:1;'>";
    html += "<input type='number' name='offm' min='0' max='59' value='" + String(schedOffMinute[i]) + "' placeholder='دقيقة' style='flex:1;'>";
    html += "</div>";

    html += "<button class='btn btn-green' type='submit' style='margin-top:14px;'>💾 حفظ جدول " + relayNames[i] + "</button>";
    html += "</form>";
    html += "</div>";
  }

  html += "<p style='color:#8a96a3;font-size:12px;'>ملحوظة: لو ميعاد الإيقاف قبل ميعاد التشغيل (مثلاً يفتح 6 مساءً ويقفل 6 صباحًا)، النظام بيتعامل معاه صح وبيعدي نص الليل عادي. كل ريليه له جدول مستقل تمامًا عن الباقي.</p>";

  html += "</div>";
  html += htmlFooter("home");
  server.send(200, "text/html", html);
}

void handleSaveSchedule() {
  int relay = server.arg("relay").toInt();
  if (relay < 0 || relay >= RELAY_COUNT) {
    server.sendHeader("Location", "/schedule");
    server.send(303);
    return;
  }

  schedEnabled[relay] = server.hasArg("en");

  int onh = server.arg("onh").toInt();
  int onm = server.arg("onm").toInt();
  int offh = server.arg("offh").toInt();
  int offm = server.arg("offm").toInt();

  if (onh >= 0 && onh <= 23) schedOnHour[relay] = onh;
  if (onm >= 0 && onm <= 59) schedOnMinute[relay] = onm;
  if (offh >= 0 && offh <= 23) schedOffHour[relay] = offh;
  if (offm >= 0 && offm <= 59) schedOffMinute[relay] = offm;

  saveScheduleForRelay(relay, schedEnabled[relay], schedOnHour[relay], schedOnMinute[relay], schedOffHour[relay], schedOffMinute[relay]);
  server.sendHeader("Location", "/schedule");
  server.send(303);
}

void handleSaveGmt() {
  int gmt = server.arg("gmt").toInt();
  if (gmt >= -12 && gmt <= 14) schedGmtOffset = gmt;
  saveScheduleGmt(schedGmtOffset);
  server.sendHeader("Location", "/schedule");
  server.send(303);
}

// ============================================================
//                       صفحة System Info
// ============================================================
String formatUptime(unsigned long ms) {
  unsigned long totalSec = ms / 1000;
  unsigned long days = totalSec / 86400;
  unsigned long hours = (totalSec % 86400) / 3600;
  unsigned long mins = (totalSec % 3600) / 60;
  unsigned long secs = totalSec % 60;

  String out = "";
  if (days > 0) out += String(days) + "d ";
  out += String(hours) + "h " + String(mins) + "m " + String(secs) + "s";
  return out;
}

String rssiQuality(int rssi) {
  if (rssi >= -55) return "ممتاز 📶";
  if (rssi >= -70) return "جيد 📶";
  if (rssi >= -80) return "ضعيف 📶";
  return "ضعيف جدًا 📶";
}

void handleSysInfoPage() {
  bool wifiOk = (WiFi.status() == WL_CONNECTED);
  bool mqttOk = mqttClient.connected();

  String html = htmlHeader("System Info");
  html.replace("</head>", "<meta http-equiv='refresh' content='5'></head>");

  html += "<div class='container'>";

  html += "<div class='section'><h2>ℹ️ System Info</h2>";

  html += "<div class='info-box'>";
  html += "🌐 <b>IP Address:</b> " + (wifiOk ? WiFi.localIP().toString() : WiFi.softAPIP().toString()) + (wifiOk ? "" : " (Access Point)") + "<br>";
  html += "🔗 <b>MAC Address:</b> " + WiFi.macAddress() + "<br>";
  html += "📶 <b>RSSI:</b> " + (wifiOk ? (String(WiFi.RSSI()) + " dBm — " + rssiQuality(WiFi.RSSI())) : String("--")) + "<br>";
  html += "🧠 <b>Free Heap:</b> " + String(ESP.getFreeHeap() / 1024) + " KB<br>";
  html += "💾 <b>Flash Size:</b> " + String(ESP.getFlashChipSize() / (1024 * 1024)) + " MB<br>";
  html += "⏱️ <b>Uptime:</b> " + formatUptime(millis());
  html += "</div>";

  html += "<div class='card-foot' style='margin-top:14px;'>";
  html += "<span>WiFi: <b style='color:" + String(wifiOk ? "#1fb87a" : "#e6544a") + "'>" + String(wifiOk ? "Connected ✅" : "Disconnected ❌") + "</b></span>";
  html += "</div>";
  html += "<div class='card-foot' style='margin-top:8px;'>";
  html += "<span>MQTT: <b style='color:" + String(mqttOk ? "#1fb87a" : "#e6544a") + "'>" + String(mqttOk ? "Connected ✅" : "Disconnected ❌") + "</b></span>";
  html += "</div>";

  html += "<p style='color:#5a6472;font-size:11.5px;margin-top:16px;text-align:center;'>🔄 الصفحة بتتحدث تلقائي كل 5 ثواني</p>";
  html += "</div></div>";

  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

// ============================================================
//                       صفحة System (OTA / Backup / Restore)
// ============================================================
void handleSystemPage() {
  String html = htmlHeader("System");
  html += "<div class='container'>";

  html += "<div class='section'><h2>⬆️ OTA Firmware Update</h2>";
  html += "<div class='info-box'>ارفع ملف <b>.bin</b> من مجلد <code>.pio/build/esp32dev/firmware.bin</code> بعد عمل Build. الجهاز هيعيد التشغيل تلقائي بعد نجاح التحديث.</div>";
  html += "<form method='POST' action='/otaupload' enctype='multipart/form-data' onsubmit=\"return confirm('هل تريد رفع فيرموير جديد؟ متقفلش الصفحة أثناء الرفع.')\">";
  html += "<input type='file' name='firmware' accept='.bin' required style='width:100%;padding:12px;border-radius:12px;background:#0f1720;border:1px solid #26313f;color:#fff;margin:8px 0;'>";
  html += "<button class='btn btn-orange' type='submit'>⬆️ Upload &amp; Flash</button>";
  html += "</form></div>";

  html += "<div class='section'><h2>💾 Backup Settings</h2>";
  html += "<p>حمّل ملف يحتوي كل إعداداتك الحالية (الشبكة، الأسماء، MQTT) عشان ترجعله وقت ما تحتاج.</p>";
  html += "<a href='/backup' class='btn btn-blue'>⬇️ Download Backup File</a>";
  html += "</div>";

  html += "<div class='section'><h2>♻️ Restore Settings</h2>";
  html += "<p>ارفع ملف backup.json اللي حفظته قبل كده، هيرجّع كل الإعدادات ويعيد تشغيل الجهاز.</p>";
  html += "<form method='POST' action='/restorefile' enctype='multipart/form-data' onsubmit=\"return confirm('هل تريد استرجاع الإعدادات من الملف؟ الإعدادات الحالية هتتستبدل.')\">";
  html += "<input type='file' name='backupfile' accept='.json' required style='width:100%;padding:12px;border-radius:12px;background:#0f1720;border:1px solid #26313f;color:#fff;margin:8px 0;'>";
  html += "<button class='btn btn-purple' type='submit'>♻️ Restore</button>";
  html += "</form></div>";

  html += "</div>";
  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

// ------------------- OTA Update -------------------
void handleOtaFileUpload() {
  HTTPUpload& upload = server.upload();

  if (upload.status == UPLOAD_FILE_START) {
    otaUploadOk = false;
    otaErrorMsg = "";
    Serial.printf("OTA Update بدأ: %s\n", upload.filename.c_str());
    if (!Update.begin(0xFFFFFFFF)) {
      otaErrorMsg = "فشل بدء التحديث (المساحة غير كافية؟)";
      Update.printError(Serial);
    }
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
      otaErrorMsg = "فشل كتابة البيانات أثناء التحديث";
      Update.printError(Serial);
    }
  } else if (upload.status == UPLOAD_FILE_END) {
    if (Update.end(true)) {
      otaUploadOk = true;
      Serial.printf("تم التحديث بنجاح: %u بايت\n", upload.totalSize);
    } else {
      otaErrorMsg = "فشل إنهاء التحديث - الملف غير صالح";
      Update.printError(Serial);
    }
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    Update.end();
    otaErrorMsg = "تم إلغاء رفع الملف";
  }
}

void handleOtaUploadResult() {
  server.sendHeader("Connection", "close");
  if (otaUploadOk) {
    server.send(200, "text/html", htmlHeader("OTA") + "<div class='container'><div class='section'><h2>✅ تم التحديث بنجاح، جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("wifi"));
    delay(1500);
    ESP.restart();
  } else {
    String msg = otaErrorMsg.length() > 0 ? otaErrorMsg : "فشل التحديث";
    server.send(200, "text/html", htmlHeader("OTA") + "<div class='container'><div class='section'><h2>❌ " + msg + "</h2><a href='/system' class='btn btn-blue'>رجوع</a></div></div>" + htmlFooter("wifi"));
  }
}

// ------------------- Backup -------------------
void handleBackup() {
  DynamicJsonDocument doc(3072);

  doc["panelTitle"] = panelTitle;
  doc["staSsid"] = staSsid;
  doc["staPass"] = staPass;
  doc["apSsid"] = apSsid;
  doc["apPass"] = apPass;
  doc["apHidden"] = apHidden;
  doc["mqttBroker"] = mqttBroker;
  doc["mqttPrefix"] = mqttPrefix;
  doc["mqttPort"] = mqttPort;

  JsonArray relays = doc.createNestedArray("relays");
  for (int i = 0; i < RELAY_COUNT; i++) {
    JsonObject r = relays.createNestedObject();
    r["name"] = relayNames[i];
    r["timer"] = relayIsTimer[i];
  }

  String output;
  serializeJsonPretty(doc, output);

  server.sendHeader("Content-Disposition", "attachment; filename=backup.json");
  server.send(200, "application/json", output);
}

// ------------------- Restore -------------------
void handleRestoreFileUpload() {
  HTTPUpload& upload = server.upload();

  if (upload.status == UPLOAD_FILE_START) {
    restoreBuffer = "";
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    for (size_t i = 0; i < upload.currentSize; i++) {
      restoreBuffer += (char)upload.buf[i];
    }
  }
}

bool applyRestoreJson(String &jsonText) {
  DynamicJsonDocument doc(3072);
  DeserializationError err = deserializeJson(doc, jsonText);
  if (err) return false;

  panelTitle = doc["panelTitle"] | panelTitle;
  staSsid    = doc["staSsid"] | staSsid;
  staPass    = doc["staPass"] | staPass;
  apSsid     = doc["apSsid"] | apSsid;
  apPass     = doc["apPass"] | apPass;
  apHidden   = doc["apHidden"] | apHidden;
  mqttBroker = doc["mqttBroker"] | mqttBroker;
  mqttPrefix = doc["mqttPrefix"] | mqttPrefix;
  mqttPort   = doc["mqttPort"] | mqttPort;

  JsonArray relays = doc["relays"];
  if (!relays.isNull()) {
    for (int i = 0; i < RELAY_COUNT && i < (int)relays.size(); i++) {
      JsonObject r = relays[i];
      relayNames[i] = (r["name"] | relayNames[i].c_str());
      relayIsTimer[i] = r["timer"] | false;
    }
  }

  savePanelTitle(panelTitle);
  saveWifiSettings(staSsid, staPass);
  saveApSettings(apSsid, apPass, apHidden);
  saveMqttSettings(mqttBroker, mqttPrefix, mqttPort);
  saveRelayNamesAndTimers();

  return true;
}

void handleRestoreResult() {
  bool ok = applyRestoreJson(restoreBuffer);
  restoreBuffer = "";

  if (ok) {
    server.send(200, "text/html", htmlHeader("Restore") + "<div class='container'><div class='section'><h2>✅ تم استرجاع الإعدادات، جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("wifi"));
    delay(1500);
    ESP.restart();
  } else {
    server.send(200, "text/html", htmlHeader("Restore") + "<div class='container'><div class='section'><h2>❌ الملف غير صالح</h2><a href='/system' class='btn btn-blue'>رجوع</a></div></div>" + htmlFooter("wifi"));
  }
}

// ============================================================
//                       Restart
// ============================================================
void handleRestart() {
  server.send(200, "text/html", htmlHeader("Restart") + "<div class='container'><div class='section'><h2>جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("home"));
  delay(1000);
  ESP.restart();
}

// ============================================================
//                       Factory Reset
// ============================================================
// الزرار الفيزيائي اتشال (مفيش بين فاضي بعد الـ8 ريليهات) - استخدم
// زرار "مسح الإعدادات" من صفحة System في المتصفح بدلاً منه

// ============================================================
//                       Setup / Loop
// ============================================================
void setup() {
  Serial.begin(115200);

  loadSettings(); // لازم نجيب globalBrightness الأول قبل ما نظبط أول حالة للبينات

  for (int i = 0; i < RELAY_COUNT; i++) {
    pinMode(relayPins[i], OUTPUT);
    relayState[i] = false;
    applyRelayOutput(i); // تأكيد إن كل مفتاح مقفول عند الإقلاع
  }
  pinMode(emergencyButtonPin, INPUT_PULLUP); // وصّل الزرار بين البين ده والجراوند

  WiFi.mode(WIFI_AP_STA);
  WiFi.setTxPower(WIFI_POWER_19_5dBm); // أقصى قوة إرسال ممكنة للـ ESP32
  WiFi.setSleep(false);                // إيقاف وضع توفير الطاقة اللي بيضعف استقرار الاتصال
  startAccessPoint();      // الـ Access Point شغال دايمًا
  connectToWifi();         // ومحاولة الاتصال بالشبكة المحفوظة كمان

  mqttClient.setServer(mqttBroker.c_str(), mqttPort);
  mqttClient.setCallback(mqttCallback);
  // مكتبة PubSubClient بتحدد حجم رسائل MQTT بـ 256 بايت بس افتراضيًا (للإرسال
  // والاستقبال). رسالة "discovery" اللي بتحتوي أسماء ومفاتيح كل الـ 6 مفاتيح
  // (relays) بتتخطى الحجم ده بسهولة، فكانت بتفشل تُنشر بصمت من غير أي خطأ
  // ظاهر — البورد يفضل متصل بالبروكر عادي، بس رسالة الاكتشاف نفسها ماكنتش
  // بتوصل خالص للتطبيق. لازم نكبّر الحجم ده قبل أي publish/subscribe.
  mqttClient.setBufferSize(2048);

  configTime(0, 0, "pool.ntp.org", "time.nist.gov"); // مزامنة الوقت (UTC) - لازم إنترنت فعلي عشان تشتغل ميزة الجدول

  server.on("/", handleRoot);
  server.on("/bg.jpg", handleBgImage);
  server.on("/control", handleControl);
  server.on("/setbrightness", handleSetBrightness);

  server.on("/wifi", handleWifiPage);
  server.on("/scanwifi", handleScanWifi);
  server.on("/savewifi", HTTP_POST, handleSaveWifi);
  server.on("/savestaticip", HTTP_POST, handleSaveStaticIp);
  server.on("/savepeer", HTTP_POST, handleSavePeer);
  server.on("/saveap", HTTP_POST, handleSaveAp);
  server.on("/clearsettings", handleClearSettings);
  server.on("/currentip", handleCurrentIp);

  server.on("/relaynames", handleRelayNamesPage);
  server.on("/saverelaynames", HTTP_POST, handleSaveRelayNames);
  server.on("/savetitle", HTTP_POST, handleSaveTitle);

  server.on("/mqtt", handleMqttPage);
  server.on("/savemqtt", HTTP_POST, handleSaveMqtt);

  server.on("/system", handleSystemPage);
  server.on("/sysinfo", handleSysInfoPage);
  server.on("/otaupload", HTTP_POST, handleOtaUploadResult, handleOtaFileUpload);
  server.on("/backup", handleBackup);
  server.on("/restorefile", HTTP_POST, handleRestoreResult, handleRestoreFileUpload);

  server.on("/emergency", handleEmergencyPage);
  server.on("/savenotify", HTTP_POST, handleSaveNotify);
  server.on("/testnotify", handleTestNotify);
  server.on("/triggeremergency", handleTriggerEmergency);
  server.on("/toggleemergencybutton", handleToggleEmergencyButton);
  server.on("/cancelemergency", handleCancelEmergency);

  server.on("/schedule", handleSchedulePage);
  server.on("/saveschedule", HTTP_POST, handleSaveSchedule);
  server.on("/savegmt", HTTP_POST, handleSaveGmt);

  server.on("/restart", handleRestart);

  server.begin();
  Serial.println("تم تشغيل السيرفر بنجاح");
}

void loop() {
  server.handleClient();
  checkWifiConnection();
  checkEmergencyButton();
  checkEmergencyTimer();
  checkTimers();
  checkSchedule();

  if (mqttEnabled) {
    if (!mqttClient.connected()) {
      static unsigned long lastAttempt = 0;
      if (millis() - lastAttempt > 5000) {
        lastAttempt = millis();
        mqttReconnect();
      }
    } else {
      mqttClient.loop();
    }
  }
}
